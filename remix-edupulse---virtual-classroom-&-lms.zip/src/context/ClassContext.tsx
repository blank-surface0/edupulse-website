import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Role,
  Student,
  AttendanceSession,
  AttendanceStatus,
  CourseMaterial,
  Assignment,
  Submission,
  ChatMessage,
  LiveSlide,
} from '../types';
import {
  INITIAL_STUDENTS,
  INITIAL_LIVE_SESSION,
  INITIAL_MATERIALS,
  INITIAL_ASSIGNMENTS,
  INITIAL_SUBMISSIONS,
  LIVE_CLASS_SLIDES,
} from '../data/initialData';

export interface Toast {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

interface ClassContextType {
  // Role & User
  role: Role;
  setRole: (role: Role) => void;
  activeStudent: Student;
  setActiveStudent: (student: Student) => void;
  students: Student[];
  updateStudent: (student: Student) => void;

  // Live Attendance Session
  liveSession: AttendanceSession;
  toggleLiveSession: (isLive: boolean) => void;
  setStudentAttendance: (studentId: string, status: AttendanceStatus, method?: 'pin' | 'manual' | 'qr' | 'facial') => void;
  checkInWithPin: (pinCode: string, studentId?: string) => { success: boolean; message: string };
  generateNewPin: () => string;
  bulkMarkAllPresent: () => void;
  resetSessionAttendance: () => void;
  isSimulatingLiveCheckins: boolean;
  setIsSimulatingLiveCheckins: (val: boolean) => void;

  // Materials Management (CRUD)
  materials: CourseMaterial[];
  addMaterial: (material: Omit<CourseMaterial, 'id' | 'uploadedAt' | 'views'>) => CourseMaterial;
  editMaterial: (id: string, updated: Partial<CourseMaterial>) => void;
  deleteMaterial: (id: string) => void;
  incrementMaterialViews: (id: string) => void;

  // Assignments Management (CRUD & Submissions)
  assignments: Assignment[];
  addAssignment: (assignment: Omit<Assignment, 'id' | 'createdAt' | 'submissionsCount'>) => Assignment;
  editAssignment: (id: string, updated: Partial<Assignment>) => void;
  deleteAssignment: (id: string) => void;

  submissions: Submission[];
  submitAssignment: (assignmentId: string, content: string, fileName?: string) => void;
  gradeSubmission: (
    submissionId: string,
    score: number,
    feedback: string,
    extra?: { aiGraded?: boolean; strengths?: string[]; improvements?: string[] }
  ) => void;

  // Live Classroom Interactive Elements
  currentSlideIndex: number;
  setCurrentSlideIndex: (idx: number) => void;
  slides: LiveSlide[];
  chatMessages: ChatMessage[];
  sendChatMessage: (text: string, isQuestion?: boolean) => void;
  raisedHands: string[]; // studentIds
  toggleRaiseHand: (studentId?: string) => void;

  // Feedback Notifications
  toasts: Toast[];
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  removeToast: (id: string) => void;
}

const ClassContext = createContext<ClassContextType | undefined>(undefined);

const STORAGE_KEYS = {
  MATERIALS: 'edupulse_materials_v2',
  ASSIGNMENTS: 'edupulse_assignments_v2',
  SUBMISSIONS: 'edupulse_submissions_v2',
  SESSION: 'edupulse_session_v2',
  STUDENTS: 'edupulse_students_v2',
};

export const ClassProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load initial from localStorage if available
  const [role, setRole] = useState<Role>('admin');
  const [students, setStudents] = useState<Student[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.STUDENTS);
    return saved ? JSON.parse(saved) : INITIAL_STUDENTS;
  });
  const [activeStudent, setActiveStudentState] = useState<Student>(students[0]);

  const [liveSession, setLiveSession] = useState<AttendanceSession>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SESSION);
    return saved ? JSON.parse(saved) : INITIAL_LIVE_SESSION;
  });

  const [materials, setMaterials] = useState<CourseMaterial[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.MATERIALS);
    return saved ? JSON.parse(saved) : INITIAL_MATERIALS;
  });

  const [assignments, setAssignments] = useState<Assignment[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ASSIGNMENTS);
    return saved ? JSON.parse(saved) : INITIAL_ASSIGNMENTS;
  });

  const [submissions, setSubmissions] = useState<Submission[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SUBMISSIONS);
    return saved ? JSON.parse(saved) : INITIAL_SUBMISSIONS;
  });

  const [toasts, setToasts] = useState<Toast[]>([]);
  const [isSimulatingLiveCheckins, setIsSimulatingLiveCheckins] = useState<boolean>(false);
  const [currentSlideIndex, setCurrentSlideIndex] = useState<number>(0);
  const [raisedHands, setRaisedHands] = useState<string[]>(['s-5']);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: 'm-1',
      senderId: 'admin',
      senderName: 'Prof. Sarah Jenkins',
      senderRole: 'admin',
      text: 'Welcome everyone to Lecture 12! Please make sure to check in using today’s live code EDU-8492.',
      timestamp: '10:00 AM',
    },
    {
      id: 'm-2',
      senderId: 's-1',
      senderName: 'Alex Rivera',
      senderRole: 'student',
      text: 'Audio and slide sharing are coming through crystal clear, Professor.',
      timestamp: '10:01 AM',
    },
    {
      id: 'm-3',
      senderId: 's-4',
      senderName: 'Priya Patel',
      senderRole: 'student',
      text: 'Quick question: will we cover network partition timeouts during split votes today?',
      timestamp: '10:04 AM',
      isQuestion: true,
    },
  ]);

  // Persist key state
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MATERIALS, JSON.stringify(materials));
  }, [materials]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ASSIGNMENTS, JSON.stringify(assignments));
  }, [assignments]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SUBMISSIONS, JSON.stringify(submissions));
  }, [submissions]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SESSION, JSON.stringify(liveSession));
  }, [liveSession]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
  }, [students]);

  // Active student sync
  const setActiveStudent = (student: Student) => {
    setActiveStudentState(student);
    showToast(`Switched active student to ${student.name}`, 'info');
  };

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = Date.now().toString() + Math.random().toString(36).substring(2, 5);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      removeToast(id);
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Live Session Attendance Controls
  const toggleLiveSession = (isLive: boolean) => {
    setLiveSession((prev) => ({
      ...prev,
      isLive,
    }));
    showToast(isLive ? 'Live classroom session started' : 'Live classroom session paused', 'info');
  };

  const setStudentAttendance = (
    studentId: string,
    status: AttendanceStatus,
    method: 'pin' | 'manual' | 'qr' | 'facial' = 'manual'
  ) => {
    const targetStudent = students.find((s) => s.id === studentId);
    const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    setLiveSession((prev) => {
      const existingIdx = prev.records.findIndex((r) => r.studentId === studentId);
      let updatedRecords = [...prev.records];

      if (existingIdx >= 0) {
        updatedRecords[existingIdx] = {
          ...updatedRecords[existingIdx],
          status,
          checkInTime: status === 'present' || status === 'late' ? nowStr : undefined,
          method,
        };
      } else if (targetStudent) {
        updatedRecords.push({
          id: `rec-${Date.now()}-${studentId}`,
          studentId: targetStudent.id,
          studentName: targetStudent.name,
          studentAvatar: targetStudent.avatar,
          status,
          checkInTime: status === 'present' || status === 'late' ? nowStr : undefined,
          method,
        });
      }

      return {
        ...prev,
        records: updatedRecords,
      };
    });

    // Update student's overall attendance stat
    setStudents((prev) =>
      prev.map((s) => {
        if (s.id === studentId) {
          const isAttended = status === 'present' || status === 'late';
          const newAttended = isAttended ? Math.min(s.totalClasses, s.totalAttended + 1) : Math.max(0, s.totalAttended - 1);
          const newRate = Math.round((newAttended / s.totalClasses) * 100);
          return {
            ...s,
            totalAttended: newAttended,
            attendanceRate: newRate,
          };
        }
        return s;
      })
    );

    showToast(`Updated attendance for ${targetStudent?.name || 'student'} to ${status.toUpperCase()}`, 'success');
  };

  const checkInWithPin = (pinCode: string, studentId?: string): { success: boolean; message: string } => {
    const sId = studentId || activeStudent.id;
    const cleanPin = pinCode.trim().toUpperCase();
    const cleanSessionPin = liveSession.pinCode.trim().toUpperCase();

    if (cleanPin !== cleanSessionPin && cleanPin !== cleanSessionPin.replace('EDU-', '')) {
      return { success: false, message: 'Invalid Attendance PIN code. Please check with your instructor.' };
    }

    if (!liveSession.isLive) {
      return { success: false, message: 'Attendance verification is closed for this session.' };
    }

    const currentRecord = liveSession.records.find((r) => r.studentId === sId);
    if (currentRecord?.status === 'present') {
      return { success: true, message: 'You have already checked in as Present for this session!' };
    }

    setStudentAttendance(sId, 'present', 'pin');
    return { success: true, message: 'Attendance successfully verified! Marked Present for today’s lecture.' };
  };

  const generateNewPin = (): string => {
    const randomCode = `EDU-${Math.floor(1000 + Math.random() * 9000)}`;
    setLiveSession((prev) => ({
      ...prev,
      pinCode: randomCode,
      pinExpiresAt: '30 mins remaining',
    }));
    showToast(`Generated new live attendance PIN: ${randomCode}`, 'success');
    return randomCode;
  };

  const bulkMarkAllPresent = () => {
    const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const allRecords = students.map((s) => ({
      id: `rec-bulk-${s.id}`,
      studentId: s.id,
      studentName: s.name,
      studentAvatar: s.avatar,
      status: 'present' as AttendanceStatus,
      checkInTime: nowStr,
      method: 'manual' as const,
    }));

    setLiveSession((prev) => ({
      ...prev,
      records: allRecords,
    }));

    setStudents((prev) =>
      prev.map((s) => ({
        ...s,
        totalAttended: Math.min(s.totalClasses, s.totalAttended + 1),
        attendanceRate: Math.min(100, Math.round(((s.totalAttended + 1) / s.totalClasses) * 100)),
      }))
    );

    showToast('All enrolled students marked Present for this session', 'success');
  };

  const resetSessionAttendance = () => {
    setLiveSession((prev) => ({
      ...prev,
      records: students.map((s) => ({
        id: `rec-reset-${s.id}`,
        studentId: s.id,
        studentName: s.name,
        studentAvatar: s.avatar,
        status: 'absent' as AttendanceStatus,
      })),
    }));
    showToast('Session attendance has been reset', 'info');
  };

  // Live Check-in Simulation for demoing real-time changes
  useEffect(() => {
    if (!isSimulatingLiveCheckins || !liveSession.isLive) return;

    const interval = setInterval(() => {
      // Find an absent student
      const absentRecord = liveSession.records.find((r) => r.status === 'absent');
      if (absentRecord) {
        setStudentAttendance(absentRecord.studentId, 'present', 'pin');
        showToast(`⚡ Real-time check-in: ${absentRecord.studentName} entered class code`, 'info');
      } else {
        setIsSimulatingLiveCheckins(false);
      }
    }, 4500);

    return () => clearInterval(interval);
  }, [isSimulatingLiveCheckins, liveSession]);

  // Materials CRUD
  const addMaterial = (newMatData: Omit<CourseMaterial, 'id' | 'uploadedAt' | 'views'>): CourseMaterial => {
    const newMaterial: CourseMaterial = {
      ...newMatData,
      id: `mat-${Date.now()}`,
      uploadedAt: 'Just now',
      views: 0,
    };
    setMaterials((prev) => [newMaterial, ...prev]);
    showToast(`Added new course material: "${newMaterial.title}"`, 'success');
    return newMaterial;
  };

  const editMaterial = (id: string, updated: Partial<CourseMaterial>) => {
    setMaterials((prev) =>
      prev.map((m) => (m.id === id ? { ...m, ...updated } : m))
    );
    showToast('Course material updated successfully', 'success');
  };

  const deleteMaterial = (id: string) => {
    const item = materials.find((m) => m.id === id);
    setMaterials((prev) => prev.filter((m) => m.id !== id));
    showToast(`Deleted material: "${item?.title || 'Material'}"`, 'info');
  };

  const incrementMaterialViews = (id: string) => {
    setMaterials((prev) =>
      prev.map((m) => (m.id === id ? { ...m, views: m.views + 1 } : m))
    );
  };

  // Assignments CRUD & Submissions
  const addAssignment = (asgData: Omit<Assignment, 'id' | 'createdAt' | 'submissionsCount'>): Assignment => {
    const newAsg: Assignment = {
      ...asgData,
      id: `asg-${Date.now()}`,
      createdAt: new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' }),
      submissionsCount: 0,
    };
    setAssignments((prev) => [newAsg, ...prev]);
    showToast(`Published assignment: "${newAsg.title}"`, 'success');
    return newAsg;
  };

  const editAssignment = (id: string, updated: Partial<Assignment>) => {
    setAssignments((prev) =>
      prev.map((a) => (a.id === id ? { ...a, ...updated } : a))
    );
    showToast('Assignment details updated', 'success');
  };

  const deleteAssignment = (id: string) => {
    const item = assignments.find((a) => a.id === id);
    setAssignments((prev) => prev.filter((a) => a.id !== id));
    // Also remove related submissions
    setSubmissions((prev) => prev.filter((s) => s.assignmentId !== id));
    showToast(`Deleted assignment: "${item?.title || 'Assignment'}"`, 'info');
  };

  const submitAssignment = (assignmentId: string, content: string, fileName?: string) => {
    const existingIdx = submissions.findIndex(
      (s) => s.assignmentId === assignmentId && s.studentId === activeStudent.id
    );

    const newSub: Submission = {
      id: existingIdx >= 0 ? submissions[existingIdx].id : `sub-${Date.now()}`,
      assignmentId,
      studentId: activeStudent.id,
      studentName: activeStudent.name,
      studentAvatar: activeStudent.avatar,
      submittedAt: 'Just now',
      content,
      fileName: fileName || `${activeStudent.name.toLowerCase().replace(/\s+/g, '_')}_solution.zip`,
      status: 'submitted',
    };

    setSubmissions((prev) => {
      if (existingIdx >= 0) {
        const copy = [...prev];
        copy[existingIdx] = newSub;
        return copy;
      }
      return [newSub, ...prev];
    });

    // Update assignment submission count
    setAssignments((prev) =>
      prev.map((a) =>
        a.id === assignmentId && existingIdx < 0
          ? { ...a, submissionsCount: (a.submissionsCount || 0) + 1 }
          : a
      )
    );

    showToast('Assignment submitted successfully! Ready for instructor review.', 'success');
  };

  const gradeSubmission = (
    submissionId: string,
    score: number,
    feedback: string,
    extra?: { aiGraded?: boolean; strengths?: string[]; improvements?: string[] }
  ) => {
    setSubmissions((prev) =>
      prev.map((sub) =>
        sub.id === submissionId
          ? {
              ...sub,
              status: 'graded',
              score,
              feedback,
              aiGraded: extra?.aiGraded,
              strengths: extra?.strengths,
              improvements: extra?.improvements,
            }
          : sub
      )
    );
    showToast('Submission graded and feedback published to student', 'success');
  };

  const updateStudent = (updatedStudent: Student) => {
    setStudents((prev) =>
      prev.map((s) => (s.id === updatedStudent.id ? updatedStudent : s))
    );
    if (activeStudent.id === updatedStudent.id) {
      setActiveStudentState(updatedStudent);
    }
  };

  // Classroom Live Chat & Interaction
  const sendChatMessage = (text: string, isQuestion: boolean = false) => {
    const newMsg: ChatMessage = {
      id: `chat-${Date.now()}`,
      senderId: role === 'admin' ? 'admin' : activeStudent.id,
      senderName: role === 'admin' ? 'Prof. Sarah Jenkins' : activeStudent.name,
      senderRole: role,
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isQuestion,
    };
    setChatMessages((prev) => [...prev, newMsg]);
  };

  const toggleRaiseHand = (studentId?: string) => {
    const sId = studentId || activeStudent.id;
    setRaisedHands((prev) => {
      const isRaised = prev.includes(sId);
      if (isRaised) {
        showToast('Lowered hand', 'info');
        return prev.filter((id) => id !== sId);
      } else {
        showToast('✋ Hand raised in live class!', 'success');
        return [...prev, sId];
      }
    });
  };

  return (
    <ClassContext.Provider
      value={{
        role,
        setRole,
        activeStudent,
        setActiveStudent,
        students,
        updateStudent,
        liveSession,
        toggleLiveSession,
        setStudentAttendance,
        checkInWithPin,
        generateNewPin,
        bulkMarkAllPresent,
        resetSessionAttendance,
        isSimulatingLiveCheckins,
        setIsSimulatingLiveCheckins,
        materials,
        addMaterial,
        editMaterial,
        deleteMaterial,
        incrementMaterialViews,
        assignments,
        addAssignment,
        editAssignment,
        deleteAssignment,
        submissions,
        submitAssignment,
        gradeSubmission,
        currentSlideIndex,
        setCurrentSlideIndex,
        slides: LIVE_CLASS_SLIDES,
        chatMessages,
        sendChatMessage,
        raisedHands,
        toggleRaiseHand,
        toasts,
        showToast,
        removeToast,
      }}
    >
      {children}
    </ClassContext.Provider>
  );
};

export const useClass = () => {
  const context = useContext(ClassContext);
  if (!context) {
    throw new Error('useClass must be used within a ClassProvider');
  }
  return context;
};
