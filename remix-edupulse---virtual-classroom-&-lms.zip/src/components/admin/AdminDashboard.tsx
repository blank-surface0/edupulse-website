import React from 'react';
import { LiveAttendanceManager } from './LiveAttendanceManager';
import { MaterialsManager } from './MaterialsManager';
import { AssignmentsManager } from './AssignmentsManager';
import { StudentRoster } from './StudentRoster';
import {
  Radio,
  FolderOpen,
  FileCheck2,
  Users,
  Sparkles,
} from 'lucide-react';

interface AdminDashboardProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ activeTab, setActiveTab }) => {
  return (
    <div className="space-y-6">
      
      {/* Admin Tab Navigation Header */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 border-b border-slate-800 text-xs">
        <button
          onClick={() => setActiveTab('attendance')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold transition whitespace-nowrap ${
            activeTab === 'attendance'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/80'
          }`}
        >
          <Radio className="w-4 h-4 text-rose-400" />
          <span>Real-Time Attendance</span>
          <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
        </button>

        <button
          onClick={() => setActiveTab('materials')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold transition whitespace-nowrap ${
            activeTab === 'materials'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/80'
          }`}
        >
          <FolderOpen className="w-4 h-4" />
          <span>Course Materials</span>
        </button>

        <button
          onClick={() => setActiveTab('assignments')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold transition whitespace-nowrap ${
            activeTab === 'assignments'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/80'
          }`}
        >
          <FileCheck2 className="w-4 h-4" />
          <span>Assignments &amp; Grading</span>
        </button>

        <button
          onClick={() => setActiveTab('roster')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold transition whitespace-nowrap ${
            activeTab === 'roster'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/80'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Student Directory</span>
        </button>
      </div>

      {/* Render Active View */}
      {activeTab === 'attendance' && <LiveAttendanceManager />}
      {activeTab === 'materials' && <MaterialsManager />}
      {activeTab === 'assignments' && <AssignmentsManager />}
      {activeTab === 'roster' && <StudentRoster />}

    </div>
  );
};
