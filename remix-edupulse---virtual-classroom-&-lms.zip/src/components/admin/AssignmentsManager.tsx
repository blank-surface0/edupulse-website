import React, { useState } from 'react';
import { useClass } from '../../context/ClassContext';
import { Assignment, Submission, RubricItem } from '../../types';
import {
  FileCheck2,
  Plus,
  Sparkles,
  Edit3,
  Trash2,
  Users,
  CheckCircle,
  Clock,
  ChevronRight,
  X,
  RefreshCw,
  Award,
  Send,
  HelpCircle,
  FileText,
} from 'lucide-react';

export const AssignmentsManager: React.FC = () => {
  const {
    assignments,
    submissions,
    addAssignment,
    editAssignment,
    deleteAssignment,
    gradeSubmission,
    students,
    showToast,
  } = useClass();

  // Selected assignment for reviewing submissions
  const [activeReviewAssignment, setActiveReviewAssignment] = useState<Assignment | null>(null);
  const [selectedSubmission, setSelectedSubmission] = useState<Submission | null>(null);

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingAssignment, setEditingAssignment] = useState<Assignment | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);

  // Grading Form State
  const [gradeScore, setGradeScore] = useState<number>(90);
  const [gradeFeedback, setGradeFeedback] = useState<string>('');
  const [gradingAiLoading, setGradingAiLoading] = useState<boolean>(false);
  const [aiGradeResult, setAiGradeResult] = useState<{
    score?: number;
    feedback?: string;
    strengths?: string[];
    improvements?: string[];
  } | null>(null);

  // Form State for Add / Edit Assignment
  const [asgForm, setAsgForm] = useState<{
    title: string;
    description: string;
    module: string;
    dueDate: string;
    totalPoints: number;
    instructionsText: string;
    rubricText: string;
    status: 'active' | 'upcoming' | 'closed';
  }>({
    title: '',
    description: '',
    module: 'Module 4: Distributed Consistency',
    dueDate: 'Nov 18, 2026, 11:59 PM',
    totalPoints: 100,
    instructionsText: '1. Build the simulated cluster.\n2. Handle election timeouts.\n3. Submit code archive and report.',
    rubricText: 'Correctness: 40\nFault Tolerance: 30\nDocumentation: 30',
    status: 'active',
  });

  // AI Assignment Generator
  const [aiTopic, setAiTopic] = useState('Byzantine Fault Tolerance and PBFT Protocol');
  const [aiDifficulty, setAiDifficulty] = useState('Advanced');
  const [aiLoading, setAiLoading] = useState(false);

  const handleOpenAdd = () => {
    setEditingAssignment(null);
    setAsgForm({
      title: '',
      description: '',
      module: 'Module 4: Distributed Consistency',
      dueDate: 'Nov 18, 2026, 11:59 PM',
      totalPoints: 100,
      instructionsText: '1. Read through the specification requirements.\n2. Implement the designated interface methods.\n3. Add unit test coverage and submit your repository link.',
      rubricText: 'Implementation Correctness: 40\nUnit Testing & Edge Cases: 30\nCode Architecture & Style: 30',
      status: 'active',
    });
    setIsAddModalOpen(true);
  };

  const handleOpenEdit = (asg: Assignment) => {
    setEditingAssignment(asg);
    setAsgForm({
      title: asg.title,
      description: asg.description,
      module: asg.module,
      dueDate: asg.dueDate,
      totalPoints: asg.totalPoints,
      instructionsText: asg.instructions.join('\n'),
      rubricText: asg.rubric.map((r) => `${r.criteria}: ${r.points}`).join('\n'),
      status: asg.status,
    });
    setIsAddModalOpen(true);
  };

  const handleSaveAssignment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!asgForm.title.trim()) {
      showToast('Assignment title is required', 'error');
      return;
    }

    const instructions = asgForm.instructionsText
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean);

    const rubric: RubricItem[] = asgForm.rubricText
      .split('\n')
      .map((line) => {
        const parts = line.split(':');
        return {
          criteria: parts[0]?.trim() || 'General Criteria',
          points: parseInt(parts[1]?.trim() || '25'),
        };
      })
      .filter((r) => r.criteria);

    if (editingAssignment) {
      editAssignment(editingAssignment.id, {
        title: asgForm.title,
        description: asgForm.description,
        module: asgForm.module,
        dueDate: asgForm.dueDate,
        totalPoints: asgForm.totalPoints,
        instructions,
        rubric,
        status: asgForm.status,
      });
    } else {
      addAssignment({
        title: asgForm.title,
        description: asgForm.description,
        module: asgForm.module,
        dueDate: asgForm.dueDate,
        totalPoints: asgForm.totalPoints,
        instructions,
        rubric,
        status: asgForm.status,
      });
    }

    setIsAddModalOpen(false);
  };

  const handleGenerateAssignmentWithAi = async () => {
    if (!aiTopic.trim()) {
      showToast('Please specify an assignment topic', 'error');
      return;
    }

    setAiLoading(true);
    try {
      const res = await fetch('/api/gemini/generate-assignment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: aiTopic,
          courseTitle: 'CS302: Cloud Architecture & High-Concurrency Systems',
          difficulty: aiDifficulty,
          totalPoints: 100,
        }),
      });

      const data = await res.json();
      if (data.error) throw new Error(data.error);

      setAsgForm({
        title: data.title || `Lab: ${aiTopic}`,
        description: data.description || '',
        module: data.module || 'Module 4: Distributed Consistency',
        dueDate: 'Nov 25, 2026, 11:59 PM',
        totalPoints: 100,
        instructionsText: (data.questions || []).join('\n'),
        rubricText: (data.rubric || []).map((r: any) => `${r.criteria}: ${r.points}`).join('\n'),
        status: 'active',
      });

      setIsAiModalOpen(false);
      setEditingAssignment(null);
      setIsAddModalOpen(true);
      showToast('Generated assignment drafted! Review and publish.', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to generate assignment', 'error');
    } finally {
      setAiLoading(false);
    }
  };

  const handleOpenReview = (asg: Assignment) => {
    setActiveReviewAssignment(asg);
    const relatedSubmissions = submissions.filter((s) => s.assignmentId === asg.id);
    if (relatedSubmissions.length > 0) {
      setSelectedSubmission(relatedSubmissions[0]);
      setGradeScore(relatedSubmissions[0].score || 92);
      setGradeFeedback(relatedSubmissions[0].feedback || '');
    } else {
      setSelectedSubmission(null);
    }
    setAiGradeResult(null);
  };

  const handleSelectSubmission = (sub: Submission) => {
    setSelectedSubmission(sub);
    setGradeScore(sub.score || 90);
    setGradeFeedback(sub.feedback || '');
    setAiGradeResult(null);
  };

  // AI Assist Grade with Gemini
  const handleAiAssistGrade = async () => {
    if (!selectedSubmission || !activeReviewAssignment) return;

    setGradingAiLoading(true);
    try {
      const res = await fetch('/api/gemini/grade-submission', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          assignmentTitle: activeReviewAssignment.title,
          assignmentDescription: activeReviewAssignment.description,
          studentSubmission: selectedSubmission.content,
          studentName: selectedSubmission.studentName,
          maxPoints: activeReviewAssignment.totalPoints,
        }),
      });

      const data = await res.json();
      if (data.error) throw new Error(data.error);

      setAiGradeResult(data);
      setGradeScore(data.score || 90);
      setGradeFeedback(data.feedback || '');
      showToast('Gemini analyzed submission and generated rubric score & feedback!', 'success');
    } catch (err: any) {
      showToast('Error generating AI grade feedback', 'error');
    } finally {
      setGradingAiLoading(false);
    }
  };

  const handleSaveGrade = () => {
    if (!selectedSubmission) return;
    gradeSubmission(selectedSubmission.id, gradeScore, gradeFeedback, {
      aiGraded: !!aiGradeResult,
      strengths: aiGradeResult?.strengths,
      improvements: aiGradeResult?.improvements,
    });
    // Update local selected state
    setSelectedSubmission({
      ...selectedSubmission,
      status: 'graded',
      score: gradeScore,
      feedback: gradeFeedback,
    });
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <FileCheck2 className="w-6 h-6 text-indigo-400" />
            Assignment &amp; Assessment Management
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Create problem sets, manage student submissions, and use Gemini AI for smart rubric grading.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => setIsAiModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/30 transition active:scale-95"
          >
            <Sparkles className="w-4 h-4" />
            AI Generate Assignment
          </button>

          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition active:scale-95"
          >
            <Plus className="w-4 h-4 text-emerald-400" />
            New Assignment
          </button>
        </div>
      </div>

      {/* Assignment Cards List */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {assignments.map((asg) => {
          const asgSubmissions = submissions.filter((s) => s.assignmentId === asg.id);
          const gradedCount = asgSubmissions.filter((s) => s.status === 'graded').length;

          return (
            <div
              key={asg.id}
              className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-5 shadow-lg flex flex-col justify-between transition group"
            >
              <div>
                {/* Status & Points Badge */}
                <div className="flex items-center justify-between gap-2 mb-3">
                  <span
                    className={`text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full ${
                      asg.status === 'active'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : asg.status === 'upcoming'
                        ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                        : 'bg-slate-800 text-slate-400 border border-slate-700'
                    }`}
                  >
                    {asg.status}
                  </span>

                  <span className="text-xs font-mono font-bold text-amber-400">
                    {asg.totalPoints} pts
                  </span>
                </div>

                <h3 className="text-base font-bold text-white group-hover:text-indigo-300 transition line-clamp-2">
                  {asg.title}
                </h3>
                <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                  {asg.description}
                </p>

                <div className="mt-3 flex items-center gap-1 text-[11px] text-slate-400">
                  <Clock className="w-3.5 h-3.5 text-rose-400" />
                  <span>Due: <strong className="text-slate-300">{asg.dueDate}</strong></span>
                </div>
              </div>

              {/* Submission Stats & Review Button */}
              <div className="mt-5 pt-4 border-t border-slate-800">
                <div className="flex items-center justify-between text-xs mb-3">
                  <span className="text-slate-400">Submissions</span>
                  <span className="font-mono font-semibold text-slate-200">
                    {asgSubmissions.length} submitted ({gradedCount} graded)
                  </span>
                </div>

                <div className="flex items-center justify-between gap-2">
                  <button
                    onClick={() => handleOpenReview(asg)}
                    className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/20 transition active:scale-95"
                  >
                    <Users className="w-3.5 h-3.5" />
                    Review &amp; Grade
                  </button>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleOpenEdit(asg)}
                      title="Edit Assignment"
                      className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setDeleteConfirmId(asg.id)}
                      title="Delete Assignment"
                      className="p-2 rounded-xl bg-slate-800 hover:bg-rose-600/30 text-rose-300 transition"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>

            </div>
          );
        })}
      </div>

      {/* Review & Grading Drawer / Modal */}
      {activeReviewAssignment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-5xl w-full h-[90vh] text-white shadow-2xl flex flex-col overflow-hidden">
            
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-bold">
                  Submissions Review &amp; Grading
                </span>
                <h3 className="text-lg font-bold text-white mt-1">
                  {activeReviewAssignment.title}
                </h3>
              </div>
              <button
                onClick={() => setActiveReviewAssignment(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Split View: Submissions List on Left, Grading Detail on Right */}
            <div className="flex-1 grid grid-cols-1 md:grid-cols-12 overflow-hidden">
              
              {/* Left Column: Submissions List */}
              <div className="md:col-span-4 border-r border-slate-800 overflow-y-auto p-3 space-y-2 bg-slate-950/40">
                <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-2 py-1">
                  Submitted Students ({submissions.filter((s) => s.assignmentId === activeReviewAssignment.id).length})
                </div>

                {submissions
                  .filter((s) => s.assignmentId === activeReviewAssignment.id)
                  .map((sub) => (
                    <button
                      key={sub.id}
                      onClick={() => handleSelectSubmission(sub)}
                      className={`w-full text-left p-3 rounded-xl border transition flex items-center justify-between ${
                        selectedSubmission?.id === sub.id
                          ? 'bg-indigo-600/20 border-indigo-500/50 text-white'
                          : 'bg-slate-900 border-slate-800 hover:border-slate-700 text-slate-300'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <img
                          src={sub.studentAvatar}
                          alt={sub.studentName}
                          className="w-8 h-8 rounded-full object-cover"
                        />
                        <div>
                          <div className="text-xs font-semibold">{sub.studentName}</div>
                          <div className="text-[10px] text-slate-400">{sub.submittedAt}</div>
                        </div>
                      </div>

                      <div>
                        {sub.status === 'graded' ? (
                          <span className="text-xs font-mono font-bold text-emerald-400">
                            {sub.score}/{activeReviewAssignment.totalPoints}
                          </span>
                        ) : (
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-semibold">
                            Pending
                          </span>
                        )}
                      </div>
                    </button>
                  ))}

                {submissions.filter((s) => s.assignmentId === activeReviewAssignment.id).length === 0 && (
                  <div className="p-6 text-center text-xs text-slate-500">
                    No student submissions recorded yet for this assignment.
                  </div>
                )}
              </div>

              {/* Right Column: Submission Review & AI Grading */}
              <div className="md:col-span-8 overflow-y-auto p-4 sm:p-6 space-y-5">
                {selectedSubmission ? (
                  <div>
                    {/* Student Submission Card */}
                    <div className="bg-slate-800/40 border border-slate-800 rounded-xl p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2.5">
                          <img
                            src={selectedSubmission.studentAvatar}
                            alt={selectedSubmission.studentName}
                            className="w-8 h-8 rounded-full object-cover"
                          />
                          <div>
                            <div className="text-sm font-bold text-white">{selectedSubmission.studentName}</div>
                            <div className="text-xs text-slate-400">Submitted: {selectedSubmission.submittedAt}</div>
                          </div>
                        </div>

                        {selectedSubmission.fileName && (
                          <div className="flex items-center gap-1.5 text-xs font-mono bg-slate-800 px-2.5 py-1 rounded-lg border border-slate-700 text-indigo-300">
                            <FileText className="w-3.5 h-3.5" />
                            {selectedSubmission.fileName}
                          </div>
                        )}
                      </div>

                      <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 font-mono text-xs text-slate-200 whitespace-pre-wrap leading-relaxed max-h-56 overflow-y-auto">
                        {selectedSubmission.content}
                      </div>
                    </div>

                    {/* Gemini AI Grading Assist Tool */}
                    <div className="mt-5 p-4 rounded-xl bg-gradient-to-r from-indigo-950/40 via-purple-950/20 to-slate-900 border border-indigo-500/30">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <Sparkles className="w-4 h-4 text-indigo-400" />
                          <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-200">
                            Gemini AI Grading Assistant
                          </h4>
                        </div>

                        <button
                          onClick={handleAiAssistGrade}
                          disabled={gradingAiLoading}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-semibold transition active:scale-95"
                        >
                          {gradingAiLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                          {gradingAiLoading ? 'Analyzing...' : 'Auto-Evaluate Submission'}
                        </button>
                      </div>
                      <p className="text-[11px] text-slate-400">
                        Gemini assesses the student's solution against rubric criteria, calculates a suggested score, and authors constructive pedagogical feedback.
                      </p>

                      {aiGradeResult && (
                        <div className="mt-3 p-3 bg-slate-900/90 rounded-xl border border-indigo-500/40 text-xs space-y-2 animate-fade-in">
                          <div className="flex items-center justify-between text-indigo-300 font-semibold">
                            <span>AI Suggested Score:</span>
                            <span className="font-mono text-emerald-400 font-bold text-sm">
                              {aiGradeResult.score} / {activeReviewAssignment.totalPoints}
                            </span>
                          </div>

                          {aiGradeResult.strengths && aiGradeResult.strengths.length > 0 && (
                            <div>
                              <span className="text-[10px] uppercase font-bold text-emerald-400">Identified Strengths:</span>
                              <ul className="list-disc pl-4 text-slate-300 text-[11px] mt-0.5 space-y-0.5">
                                {aiGradeResult.strengths.map((str, i) => (
                                  <li key={i}>{str}</li>
                                ))}
                              </ul>
                            </div>
                          )}

                          {aiGradeResult.improvements && aiGradeResult.improvements.length > 0 && (
                            <div>
                              <span className="text-[10px] uppercase font-bold text-amber-400">Growth Opportunities:</span>
                              <ul className="list-disc pl-4 text-slate-300 text-[11px] mt-0.5 space-y-0.5">
                                {aiGradeResult.improvements.map((imp, i) => (
                                  <li key={i}>{imp}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Grading Form (Score + Written Feedback) */}
                    <div className="mt-5 space-y-3">
                      <div className="flex items-center justify-between">
                        <label className="text-xs font-bold uppercase tracking-wider text-slate-300">
                          Final Score (out of {activeReviewAssignment.totalPoints})
                        </label>
                        <input
                          type="number"
                          min={0}
                          max={activeReviewAssignment.totalPoints}
                          value={gradeScore}
                          onChange={(e) => setGradeScore(parseInt(e.target.value) || 0)}
                          className="w-24 bg-slate-800 border border-slate-700 rounded-xl px-3 py-1.5 text-center font-mono font-bold text-amber-400 text-sm focus:outline-none focus:border-indigo-500"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1">
                          Instructor Feedback &amp; Rubric Commentary
                        </label>
                        <textarea
                          rows={4}
                          value={gradeFeedback}
                          onChange={(e) => setGradeFeedback(e.target.value)}
                          placeholder="Provide constructive feedback, notes on edge cases, and recommendations..."
                          className="w-full bg-slate-800 border border-slate-700 rounded-xl p-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 leading-relaxed"
                        />
                      </div>

                      <div className="flex items-center justify-end gap-2 pt-2">
                        <button
                          onClick={handleSaveGrade}
                          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs shadow-md shadow-emerald-600/20 transition active:scale-95"
                        >
                          <Award className="w-4 h-4" />
                          Publish Grade to Student
                        </button>
                      </div>
                    </div>

                  </div>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-center text-slate-500 p-8">
                    <FileCheck2 className="w-12 h-12 text-slate-600 mb-2" />
                    <p className="text-sm font-semibold">Select a student submission to evaluate</p>
                  </div>
                )}
              </div>

            </div>

          </div>
        </div>
      )}

      {/* Add / Edit Assignment Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 text-white shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setIsAddModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-bold text-white mb-4">
              {editingAssignment ? 'Edit Assignment' : 'Create New Assignment'}
            </h3>

            <form onSubmit={handleSaveAssignment} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Assignment Title *</label>
                <input
                  type="text"
                  required
                  value={asgForm.title}
                  onChange={(e) => setAsgForm({ ...asgForm, title: e.target.value })}
                  placeholder="e.g. Lab 4: Raft Leader Election State Machine"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Brief Description</label>
                <textarea
                  rows={2}
                  value={asgForm.description}
                  onChange={(e) => setAsgForm({ ...asgForm, description: e.target.value })}
                  placeholder="Summary of goals and engineering context..."
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Module</label>
                  <input
                    type="text"
                    value={asgForm.module}
                    onChange={(e) => setAsgForm({ ...asgForm, module: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">Total Points</label>
                  <input
                    type="number"
                    value={asgForm.totalPoints}
                    onChange={(e) => setAsgForm({ ...asgForm, totalPoints: parseInt(e.target.value) || 100 })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Due Date</label>
                  <input
                    type="text"
                    value={asgForm.dueDate}
                    onChange={(e) => setAsgForm({ ...asgForm, dueDate: e.target.value })}
                    placeholder="Nov 20, 2026, 11:59 PM"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">Status</label>
                  <select
                    value={asgForm.status}
                    onChange={(e) => setAsgForm({ ...asgForm, status: e.target.value as any })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="active">Active (Open for submissions)</option>
                    <option value="upcoming">Upcoming (Scheduled)</option>
                    <option value="closed">Closed (Submissions locked)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Instructions &amp; Prompts (One per line)
                </label>
                <textarea
                  rows={4}
                  value={asgForm.instructionsText}
                  onChange={(e) => setAsgForm({ ...asgForm, instructionsText: e.target.value })}
                  placeholder="Task 1...&#10;Task 2..."
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 font-mono text-[11px] focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Rubric Criteria (Format: "Criteria: Points", e.g. "Code Quality: 30")
                </label>
                <textarea
                  rows={3}
                  value={asgForm.rubricText}
                  onChange={(e) => setAsgForm({ ...asgForm, rubricText: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 font-mono text-[11px] focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold shadow-md shadow-indigo-600/30 transition active:scale-95"
                >
                  {editingAssignment ? 'Save Changes' : 'Publish Assignment'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Gemini AI Assignment Generator Modal */}
      {isAiModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-indigo-500/40 rounded-2xl max-w-md w-full p-6 text-white shadow-2xl relative">
            <button
              onClick={() => setIsAiModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 mb-3 text-indigo-400">
              <Sparkles className="w-5 h-5" />
              <h3 className="text-base font-bold text-white">Generate Assignment with Gemini</h3>
            </div>
            <p className="text-xs text-slate-400 mb-4">
              Gemini will generate structured tasks, testing prompts, and weighted rubric breakdown.
            </p>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Topic / Subject</label>
                <input
                  type="text"
                  value={aiTopic}
                  onChange={(e) => setAiTopic(e.target.value)}
                  placeholder="e.g. Sharded Key-Value Stores with Consistent Hashing"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Target Difficulty</label>
                <select
                  value={aiDifficulty}
                  onChange={(e) => setAiDifficulty(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                >
                  <option value="Foundational">Foundational / Conceptual</option>
                  <option value="Intermediate">Intermediate / Practical Implementation</option>
                  <option value="Advanced">Advanced / High-Scale Production System</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4">
                <button
                  type="button"
                  onClick={() => setIsAiModalOpen(false)}
                  className="px-3 py-2 rounded-xl text-slate-400 hover:text-white transition"
                >
                  Cancel
                </button>
                <button
                  onClick={handleGenerateAssignmentWithAi}
                  disabled={aiLoading}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 disabled:opacity-50 text-white font-semibold shadow-md shadow-indigo-600/30 transition active:scale-95"
                >
                  {aiLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                  {aiLoading ? 'Generating...' : 'Generate with Gemini'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-rose-500/40 rounded-2xl max-w-sm w-full p-6 text-white shadow-2xl">
            <h4 className="text-base font-bold text-white mb-2">Delete Assignment?</h4>
            <p className="text-xs text-slate-400 mb-5">
              Deleting this assignment will also erase all associated student submissions and recorded grades.
            </p>
            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-3 py-1.5 rounded-xl text-xs text-slate-400 hover:text-white transition"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  deleteAssignment(deleteConfirmId);
                  setDeleteConfirmId(null);
                }}
                className="px-4 py-1.5 rounded-xl text-xs bg-rose-600 hover:bg-rose-500 text-white font-semibold transition active:scale-95"
              >
                Delete Assignment
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
