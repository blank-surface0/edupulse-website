import React, { useState } from 'react';
import { useClass } from '../../context/ClassContext';
import { CourseMaterial, MaterialCategory } from '../../types';
import {
  FileText,
  Plus,
  Sparkles,
  Search,
  Filter,
  Edit2,
  Trash2,
  Eye,
  Download,
  BookOpen,
  Code,
  Video,
  FileCheck,
  X,
  RefreshCw,
  FolderOpen,
} from 'lucide-react';

export const MaterialsManager: React.FC = () => {
  const { materials, addMaterial, editMaterial, deleteMaterial, incrementMaterialViews, showToast } = useClass();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  
  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingMaterial, setEditingMaterial] = useState<CourseMaterial | null>(null);
  const [previewMaterial, setPreviewMaterial] = useState<CourseMaterial | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);

  // Form State for Add / Edit
  const [formState, setFormState] = useState<{
    title: string;
    description: string;
    category: MaterialCategory;
    module: string;
    week: number;
    fileType: string;
    fileSize: string;
    content: string;
  }>({
    title: '',
    description: '',
    category: 'slides',
    module: 'Module 4: Distributed Consistency',
    week: 6,
    fileType: 'PDF Deck',
    fileSize: '4.5 MB',
    content: '',
  });

  // AI Generator Form State
  const [aiTopic, setAiTopic] = useState('Distributed Consensus and Leader Election In Raft');
  const [aiType, setAiType] = useState('Study Guide & Lecture Notes');
  const [aiLoading, setAiLoading] = useState(false);

  // Filter materials
  const filteredMaterials = materials.filter((mat) => {
    const matchesSearch =
      mat.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      mat.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      mat.module.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || mat.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getCategoryIcon = (cat: MaterialCategory) => {
    switch (cat) {
      case 'slides':
        return <FileText className="w-5 h-5 text-indigo-400" />;
      case 'code':
        return <Code className="w-5 h-5 text-emerald-400" />;
      case 'video':
        return <Video className="w-5 h-5 text-rose-400" />;
      case 'cheatsheet':
        return <FileCheck className="w-5 h-5 text-amber-400" />;
      default:
        return <BookOpen className="w-5 h-5 text-sky-400" />;
    }
  };

  const handleOpenAdd = () => {
    setFormState({
      title: '',
      description: '',
      category: 'slides',
      module: 'Module 4: Distributed Consistency',
      week: 6,
      fileType: 'PDF Deck',
      fileSize: '3.2 MB',
      content: '',
    });
    setEditingMaterial(null);
    setIsAddModalOpen(true);
  };

  const handleOpenEdit = (mat: CourseMaterial) => {
    setEditingMaterial(mat);
    setFormState({
      title: mat.title,
      description: mat.description,
      category: mat.category,
      module: mat.module,
      week: mat.week,
      fileType: mat.fileType,
      fileSize: mat.fileSize || '2.0 MB',
      content: mat.content || '',
    });
    setIsAddModalOpen(true);
  };

  const handleSaveMaterial = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formState.title.trim()) {
      showToast('Please enter a title for the material', 'error');
      return;
    }

    if (editingMaterial) {
      editMaterial(editingMaterial.id, formState);
    } else {
      addMaterial(formState);
    }

    setIsAddModalOpen(false);
    setEditingMaterial(null);
  };

  const handleConfirmDelete = () => {
    if (deleteConfirmId) {
      deleteMaterial(deleteConfirmId);
      setDeleteConfirmId(null);
    }
  };

  const handleGenerateWithAi = async () => {
    if (!aiTopic.trim()) {
      showToast('Please enter a topic', 'error');
      return;
    }

    setAiLoading(true);
    try {
      const res = await fetch('/api/gemini/generate-material', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: aiTopic,
          courseTitle: 'CS302: Cloud Architecture & High-Concurrency Systems',
          type: aiType,
        }),
      });

      const data = await res.json();
      if (data.error) throw new Error(data.error);

      // Pre-populate form with generated content
      setFormState({
        title: data.title || `Lecture Notes: ${aiTopic}`,
        description: data.summary || `Comprehensive learning guide on ${aiTopic}.`,
        category: 'notes',
        module: 'Module 4: Distributed Consistency',
        week: 6,
        fileType: 'Markdown Doc',
        fileSize: '1.5 MB',
        content: data.content || '',
      });

      setIsAiModalOpen(false);
      setEditingMaterial(null);
      setIsAddModalOpen(true);
      showToast('AI Study Guide generated! Review and save to publish.', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to generate material via AI', 'error');
    } finally {
      setAiLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Materials Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <FolderOpen className="w-6 h-6 text-indigo-400" />
            Course Materials Management
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Publish, edit, and organize lecture slides, reading notes, and reference guides for students.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => setIsAiModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/30 transition active:scale-95"
          >
            <Sparkles className="w-4 h-4" />
            Generate with Gemini
          </button>

          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition active:scale-95"
          >
            <Plus className="w-4 h-4 text-emerald-400" />
            Add Material
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-900/60 border border-slate-800 p-3 rounded-xl">
        {/* Search */}
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search slides, topics, or modules..."
            className="w-full bg-slate-800/80 border border-slate-700/80 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>

        {/* Categories */}
        <div className="flex items-center gap-1 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0 text-xs">
          {[
            { id: 'all', label: 'All Files' },
            { id: 'slides', label: 'Slides' },
            { id: 'reading', label: 'Readings' },
            { id: 'notes', label: 'Notes' },
            { id: 'code', label: 'Code' },
            { id: 'cheatsheet', label: 'Cheatsheets' },
            { id: 'video', label: 'Videos' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap capitalize font-medium transition ${
                selectedCategory === cat.id
                  ? 'bg-indigo-600 text-white font-semibold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Materials Grid / List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredMaterials.map((mat) => (
          <div
            key={mat.id}
            className="bg-slate-900 border border-slate-800 hover:border-slate-700/80 rounded-2xl p-5 shadow-lg transition flex flex-col justify-between group"
          >
            <div>
              {/* Category, Module & Week */}
              <div className="flex items-center justify-between gap-2 mb-2">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-slate-800 border border-slate-700/60">
                    {getCategoryIcon(mat.category)}
                  </div>
                  <div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 uppercase font-semibold">
                      {mat.category}
                    </span>
                    <span className="text-[11px] text-slate-400 ml-2 font-mono">Week {mat.week}</span>
                  </div>
                </div>

                <div className="text-[11px] text-slate-500 font-mono">
                  {mat.fileSize}
                </div>
              </div>

              {/* Title & Description */}
              <h3 className="text-base font-bold text-white group-hover:text-indigo-300 transition line-clamp-1">
                {mat.title}
              </h3>
              <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                {mat.description}
              </p>

              <div className="mt-2 text-[11px] text-indigo-400/90 font-medium">
                {mat.module}
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="mt-4 pt-4 border-t border-slate-800/80 flex items-center justify-between">
              <div className="flex items-center gap-2 text-[11px] text-slate-500">
                <span>{mat.uploadedAt}</span>
                <span>•</span>
                <span>{mat.views} views</span>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => {
                    incrementMaterialViews(mat.id);
                    setPreviewMaterial(mat);
                  }}
                  title="Preview Material"
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                >
                  <Eye className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => handleOpenEdit(mat)}
                  title="Edit Material"
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-indigo-600/30 text-indigo-300 transition"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => setDeleteConfirmId(mat.id)}
                  title="Delete Material"
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-600/30 text-rose-300 transition"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

          </div>
        ))}
      </div>

      {filteredMaterials.length === 0 && (
        <div className="text-center py-12 bg-slate-900 border border-slate-800 rounded-2xl text-slate-400">
          <FolderOpen className="w-12 h-12 mx-auto text-slate-600 mb-2" />
          <p className="text-sm font-semibold">No materials found matching your criteria</p>
          <p className="text-xs text-slate-500 mt-1">Try adjusting your search query or category filter</p>
        </div>
      )}

      {/* Add / Edit Material Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 text-white shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setIsAddModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-bold text-white mb-4">
              {editingMaterial ? 'Edit Course Material' : 'Add New Course Material'}
            </h3>

            <form onSubmit={handleSaveMaterial} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Title *</label>
                <input
                  type="text"
                  required
                  value={formState.title}
                  onChange={(e) => setFormState({ ...formState, title: e.target.value })}
                  placeholder="e.g. Lecture 12 Slides: Distributed Consensus"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Short Description</label>
                <textarea
                  rows={2}
                  value={formState.description}
                  onChange={(e) => setFormState({ ...formState, description: e.target.value })}
                  placeholder="Brief summary of what this document or lecture covers..."
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Category</label>
                  <select
                    value={formState.category}
                    onChange={(e) => setFormState({ ...formState, category: e.target.value as MaterialCategory })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="slides">Slides (PDF Deck)</option>
                    <option value="reading">Reading Document</option>
                    <option value="notes">Lecture Notes</option>
                    <option value="code">Code Repository</option>
                    <option value="cheatsheet">Cheatsheet</option>
                    <option value="video">Video Recording</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">Week Number</label>
                  <input
                    type="number"
                    min={1}
                    max={20}
                    value={formState.week}
                    onChange={(e) => setFormState({ ...formState, week: parseInt(e.target.value) || 1 })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Module Name</label>
                  <input
                    type="text"
                    value={formState.module}
                    onChange={(e) => setFormState({ ...formState, module: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">File Size / Type</label>
                  <input
                    type="text"
                    value={formState.fileSize}
                    onChange={(e) => setFormState({ ...formState, fileSize: e.target.value })}
                    placeholder="e.g. 5.2 MB"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Full Document Content (Markdown Supported)
                </label>
                <textarea
                  rows={6}
                  value={formState.content}
                  onChange={(e) => setFormState({ ...formState, content: e.target.value })}
                  placeholder="# Lecture Notes Content...&#10;- Point 1&#10;- Point 2"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 font-mono text-[11px] focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold shadow-md shadow-indigo-600/30 transition active:scale-95"
                >
                  {editingMaterial ? 'Save Changes' : 'Publish Material'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Gemini AI Material Generator Modal */}
      {isAiModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-indigo-500/40 rounded-2xl max-w-md w-full p-6 text-white shadow-2xl relative">
            <button
              onClick={() => setIsAiModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 mb-3 text-indigo-400">
              <Sparkles className="w-5 h-5" />
              <h3 className="text-base font-bold text-white">Generate Material with Gemini</h3>
            </div>
            <p className="text-xs text-slate-400 mb-4">
              Enter any lecture topic or textbook concept. Gemini 3.8 Flash will author a complete, structured study document.
            </p>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Topic / Lecture Subject</label>
                <input
                  type="text"
                  value={aiTopic}
                  onChange={(e) => setAiTopic(e.target.value)}
                  placeholder="e.g. Vector Clocks and Causal Consistency"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Format Type</label>
                <select
                  value={aiType}
                  onChange={(e) => setAiType(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                >
                  <option value="Study Guide & Lecture Notes">Comprehensive Study Guide &amp; Notes</option>
                  <option value="Executive Cheat Sheet">Executive Formula &amp; Architecture Cheat Sheet</option>
                  <option value="Hands-on Lab Walkthrough">Hands-on Lab &amp; Code Walkthrough</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4">
                <button
                  type="button"
                  onClick={() => setIsAiModalOpen(false)}
                  className="px-3 py-2 rounded-xl text-slate-400 hover:text-white transition"
                >
                  Cancel
                </button>
                <button
                  onClick={handleGenerateWithAi}
                  disabled={aiLoading}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 disabled:opacity-50 text-white font-semibold shadow-md shadow-indigo-600/30 transition active:scale-95"
                >
                  {aiLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                  {aiLoading ? 'Drafting Material...' : 'Generate with Gemini'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-rose-500/40 rounded-2xl max-w-sm w-full p-6 text-white shadow-2xl">
            <h4 className="text-base font-bold text-white mb-2">Delete Course Material?</h4>
            <p className="text-xs text-slate-400 mb-5">
              Are you sure you want to delete this resource? Students will no longer have access to it.
            </p>
            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-3 py-1.5 rounded-xl text-xs text-slate-400 hover:text-white transition"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmDelete}
                className="px-4 py-1.5 rounded-xl text-xs bg-rose-600 hover:bg-rose-500 text-white font-semibold transition active:scale-95"
              >
                Delete Resource
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Material Reader / Preview Modal */}
      {previewMaterial && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full p-6 text-white shadow-2xl relative max-h-[85vh] flex flex-col">
            <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-800">
              <div>
                <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-bold">
                  {previewMaterial.category} • Week {previewMaterial.week}
                </span>
                <h3 className="text-lg font-bold text-white mt-1.5">{previewMaterial.title}</h3>
                <p className="text-xs text-slate-400">{previewMaterial.module}</p>
              </div>
              <button
                onClick={() => setPreviewMaterial(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="py-4 overflow-y-auto space-y-4 text-xs leading-relaxed text-slate-300">
              <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/60">
                <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                  Resource Summary
                </div>
                <p>{previewMaterial.description}</p>
              </div>

              {previewMaterial.content ? (
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 font-mono text-[11px] whitespace-pre-wrap text-slate-200">
                  {previewMaterial.content}
                </div>
              ) : (
                <div className="p-8 text-center text-slate-500">
                  Full binary document hosted securely. Download available for enrolled students.
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
              <span className="text-[11px] text-slate-500">File Type: {previewMaterial.fileType}</span>
              <button
                onClick={() => {
                  showToast(`Downloaded ${previewMaterial.title}`, 'success');
                  setPreviewMaterial(null);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition"
              >
                <Download className="w-3.5 h-3.5" />
                Download Attachment ({previewMaterial.fileSize})
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
