import React, { useState } from 'react';
import { useClass } from '../../context/ClassContext';
import { Users, Search, AlertTriangle, CheckCircle, Mail, Award, Clock } from 'lucide-react';

export const StudentRoster: React.FC = () => {
  const { students, submissions, assignments, showToast } = useClass();
  const [search, setSearch] = useState('');
  const [filterAtRisk, setFilterAtRisk] = useState(false);

  const filtered = students.filter((s) => {
    const matchQuery =
      s.name.toLowerCase().includes(search.toLowerCase()) ||
      s.studentId.toLowerCase().includes(search.toLowerCase()) ||
      s.email.toLowerCase().includes(search.toLowerCase());
    const matchRisk = filterAtRisk ? s.attendanceRate < 85 : true;
    return matchQuery && matchRisk;
  });

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Users className="w-6 h-6 text-indigo-400" />
            Student Directory &amp; Performance Profiles
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Monitor cumulative attendance records, assignment submission rates, and retention health.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setFilterAtRisk(!filterAtRisk)}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold border transition ${
              filterAtRisk
                ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
            {filterAtRisk ? 'Showing At-Risk Students (<85%)' : 'Filter At-Risk (<85%)'}
          </button>
        </div>
      </div>

      {/* Search Input */}
      <div className="relative max-w-md">
        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Filter roster by student name, ID, or email..."
          className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 shadow-inner"
        />
      </div>

      {/* Roster Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {filtered.map((student) => {
          const studentSubmissions = submissions.filter((sub) => sub.studentId === student.id);
          const gradedSubmissions = studentSubmissions.filter((sub) => sub.status === 'graded');
          const avgScore =
            gradedSubmissions.length > 0
              ? Math.round(
                  gradedSubmissions.reduce((acc, curr) => acc + (curr.score || 0), 0) /
                    gradedSubmissions.length
                )
              : null;

          const isAtRisk = student.attendanceRate < 85;

          return (
            <div
              key={student.id}
              className={`bg-slate-900 border rounded-2xl p-5 shadow-lg flex flex-col justify-between transition ${
                isAtRisk ? 'border-rose-900/40 hover:border-rose-800' : 'border-slate-800 hover:border-slate-700'
              }`}
            >
              <div>
                {/* Avatar & Badges */}
                <div className="flex items-start justify-between gap-2 mb-3">
                  <img
                    src={student.avatar}
                    alt={student.name}
                    className="w-12 h-12 rounded-full object-cover ring-2 ring-slate-700"
                  />
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                      isAtRisk
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                        : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    }`}
                  >
                    {isAtRisk ? 'Needs Attention' : 'Good Standing'}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-white line-clamp-1">{student.name}</h3>
                <p className="text-[11px] font-mono text-slate-400">{student.studentId}</p>
                <p className="text-[11px] text-slate-500 truncate mt-0.5">{student.email}</p>

                {/* Attendance Gauge */}
                <div className="mt-4 pt-3 border-t border-slate-800">
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="text-slate-400">Attendance Rate</span>
                    <span
                      className={`font-mono font-bold ${
                        student.attendanceRate >= 90
                          ? 'text-emerald-400'
                          : student.attendanceRate >= 80
                          ? 'text-amber-400'
                          : 'text-rose-400'
                      }`}
                    >
                      {student.attendanceRate}%
                    </span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        student.attendanceRate >= 90
                          ? 'bg-emerald-500'
                          : student.attendanceRate >= 80
                          ? 'bg-amber-500'
                          : 'bg-rose-500'
                      }`}
                      style={{ width: `${student.attendanceRate}%` }}
                    />
                  </div>
                  <div className="text-[10px] text-slate-500 mt-1">
                    {student.totalAttended} of {student.totalClasses} lectures attended
                  </div>
                </div>

                {/* Assignment Metrics */}
                <div className="mt-3 flex items-center justify-between text-xs bg-slate-800/40 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-400 flex items-center gap-1">
                    <Award className="w-3.5 h-3.5 text-indigo-400" />
                    Avg Score
                  </span>
                  <span className="font-mono font-semibold text-slate-200">
                    {avgScore !== null ? `${avgScore}%` : 'N/A'}
                  </span>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-500">
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {student.lastActive || 'Active today'}
                </span>
                <button
                  onClick={() => showToast(`Simulated direct message to ${student.email}`, 'info')}
                  className="text-indigo-400 hover:text-indigo-300 font-medium"
                >
                  Contact
                </button>
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
};
