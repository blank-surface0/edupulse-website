import React, { useState } from 'react';
import { useClass } from '../../context/ClassContext';
import { AttendanceStatus } from '../../types';
import {
  Users,
  CheckCircle2,
  Clock,
  XCircle,
  QrCode,
  RefreshCw,
  Copy,
  Check,
  Sparkles,
  Download,
  Search,
  Radio,
  Play,
  Pause,
  AlertCircle,
  Lightbulb,
} from 'lucide-react';
import { QRCodeModal } from '../common/QRCodeModal';

export const LiveAttendanceManager: React.FC = () => {
  const {
    liveSession,
    toggleLiveSession,
    setStudentAttendance,
    generateNewPin,
    bulkMarkAllPresent,
    resetSessionAttendance,
    isSimulatingLiveCheckins,
    setIsSimulatingLiveCheckins,
    students,
    showToast,
  } = useClass();

  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | AttendanceStatus>('all');
  const [showQR, setShowQR] = useState(false);
  const [copiedPin, setCopiedPin] = useState(false);

  // Gemini AI Insights State
  const [aiLoading, setAiLoading] = useState(false);
  const [aiInsights, setAiInsights] = useState<{
    healthScore?: string;
    trend?: string;
    keyObservations?: string[];
    recommendations?: string[];
  } | null>(null);

  // Calculate stats
  const totalEnrolled = students.length;
  const presentCount = liveSession.records.filter((r) => r.status === 'present').length;
  const lateCount = liveSession.records.filter((r) => r.status === 'late').length;
  const absentCount = liveSession.records.filter((r) => r.status === 'absent').length;
  const attendanceRate = totalEnrolled > 0 ? Math.round(((presentCount + lateCount) / totalEnrolled) * 100) : 0;

  // Filter students
  const filteredStudents = students.filter((student) => {
    const matchSearch =
      student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.studentId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.email.toLowerCase().includes(searchQuery.toLowerCase());

    const record = liveSession.records.find((r) => r.studentId === student.id);
    const status = record?.status || 'absent';

    const matchFilter = filterStatus === 'all' || status === filterStatus;
    return matchSearch && matchFilter;
  });

  const handleCopyPin = () => {
    navigator.clipboard.writeText(liveSession.pinCode);
    setCopiedPin(true);
    showToast(`PIN ${liveSession.pinCode} copied to clipboard`, 'success');
    setTimeout(() => setCopiedPin(false), 2000);
  };

  const handleExportCSV = () => {
    const headers = 'Student ID,Student Name,Email,Attendance Status,Check-in Time,Method\n';
    const rows = students
      .map((s) => {
        const record = liveSession.records.find((r) => r.studentId === s.id);
        const status = record?.status || 'absent';
        const time = record?.checkInTime || 'N/A';
        const method = record?.method || 'N/A';
        return `"${s.studentId}","${s.name}","${s.email}","${status}","${time}","${method}"`;
      })
      .join('\n');

    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `attendance_${liveSession.date}_CS302.csv`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Attendance report exported to CSV', 'success');
  };

  const handleFetchAiInsights = async () => {
    setAiLoading(true);
    try {
      const res = await fetch('/api/gemini/attendance-insights', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          attendanceStats: {
            totalEnrolled,
            presentCount,
            lateCount,
            absentCount,
            attendanceRate: `${attendanceRate}%`,
          },
          recentSessions: [
            { date: 'Nov 02', rate: '88%', topic: 'Distributed Consensus' },
            { date: 'Oct 30', rate: '92%', topic: 'Event Streaming' },
            { date: 'Oct 26', rate: '84%', topic: 'Network Partitions' },
          ],
        }),
      });
      const data = await res.json();
      setAiInsights(data);
      showToast('Generated fresh Gemini AI Attendance Insights', 'success');
    } catch (err: any) {
      showToast('Failed to load AI insights. Check server connection.', 'error');
    } finally {
      setAiLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner: Session Controls & Real-Time Stats */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
        {/* Subtle background glow */}
        <div className="absolute -right-20 -top-20 w-72 h-72 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          
          {/* Left: Session Info */}
          <div>
            <div className="flex items-center gap-3">
              <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold tracking-wide uppercase ${
                liveSession.isLive
                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                  : 'bg-slate-800 text-slate-400 border border-slate-700'
              }`}>
                {liveSession.isLive && (
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                )}
                {liveSession.isLive ? 'Real-Time Session Live' : 'Session Paused'}
              </span>
              <span className="text-xs text-slate-400 font-mono">
                {liveSession.date} • {liveSession.startTime} - {liveSession.endTime}
              </span>
            </div>

            <h2 className="text-xl sm:text-2xl font-bold text-white mt-2">
              {liveSession.topic}
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Course: <span className="text-slate-300 font-medium">{liveSession.courseName}</span>
            </p>
          </div>

          {/* Right: Live PIN Card */}
          <div className="flex flex-wrap items-center gap-3 bg-slate-800/80 p-3.5 rounded-xl border border-slate-700/80">
            <div>
              <div className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                Live Attendance Code
              </div>
              <div className="text-2xl sm:text-3xl font-mono font-extrabold text-amber-400 tracking-wider mt-0.5">
                {liveSession.pinCode}
              </div>
            </div>

            <div className="flex items-center gap-1.5 pl-2 border-l border-slate-700">
              <button
                onClick={handleCopyPin}
                title="Copy PIN Code"
                className="p-2 rounded-lg bg-slate-700/80 hover:bg-slate-600 text-slate-200 transition active:scale-95"
              >
                {copiedPin ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
              <button
                onClick={() => setShowQR(true)}
                title="Show Projector QR Code"
                className="p-2 rounded-lg bg-indigo-600/80 hover:bg-indigo-600 text-white transition active:scale-95"
              >
                <QrCode className="w-4 h-4" />
              </button>
              <button
                onClick={generateNewPin}
                title="Regenerate New Code"
                className="p-2 rounded-lg bg-slate-700/80 hover:bg-slate-600 text-slate-200 transition active:scale-95"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>
          </div>

        </div>

        {/* Attendance KPI Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 mt-6 pt-6 border-t border-slate-800">
          <div className="bg-slate-800/50 p-3.5 rounded-xl border border-slate-800">
            <div className="flex items-center justify-between text-slate-400 text-xs">
              <span>Total Enrolled</span>
              <Users className="w-4 h-4 text-indigo-400" />
            </div>
            <div className="text-2xl font-bold text-white mt-1">{totalEnrolled}</div>
            <div className="text-[11px] text-slate-400 mt-0.5">Class capacity</div>
          </div>

          <div className="bg-emerald-950/20 p-3.5 rounded-xl border border-emerald-900/40">
            <div className="flex items-center justify-between text-emerald-400 text-xs">
              <span>Present Today</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-2xl font-bold text-emerald-300 mt-1">{presentCount}</div>
            <div className="text-[11px] text-emerald-400/80 mt-0.5">Verified on-time</div>
          </div>

          <div className="bg-amber-950/20 p-3.5 rounded-xl border border-amber-900/40">
            <div className="flex items-center justify-between text-amber-400 text-xs">
              <span>Late</span>
              <Clock className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-2xl font-bold text-amber-300 mt-1">{lateCount}</div>
            <div className="text-[11px] text-amber-400/80 mt-0.5">Checked in after 10:15</div>
          </div>

          <div className="bg-rose-950/20 p-3.5 rounded-xl border border-rose-900/40">
            <div className="flex items-center justify-between text-rose-400 text-xs">
              <span>Absent</span>
              <XCircle className="w-4 h-4 text-rose-400" />
            </div>
            <div className="text-2xl font-bold text-rose-300 mt-1">{absentCount}</div>
            <div className="text-[11px] text-rose-400/80 mt-0.5">Awaiting check-in</div>
          </div>
        </div>

        {/* Live Attendance Progress Bar */}
        <div className="mt-4">
          <div className="flex items-center justify-between text-xs font-semibold mb-1.5">
            <span className="text-slate-300">Live Attendance Participation</span>
            <span className="text-indigo-400 font-mono">{attendanceRate}%</span>
          </div>
          <div className="w-full bg-slate-800 rounded-full h-3 overflow-hidden flex">
            <div
              className="bg-emerald-500 transition-all duration-500"
              style={{ width: `${(presentCount / totalEnrolled) * 100}%` }}
              title={`Present: ${presentCount}`}
            />
            <div
              className="bg-amber-500 transition-all duration-500"
              style={{ width: `${(lateCount / totalEnrolled) * 100}%` }}
              title={`Late: ${lateCount}`}
            />
          </div>
        </div>

        {/* Admin Action Buttons Bar */}
        <div className="mt-5 pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => toggleLiveSession(!liveSession.isLive)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition active:scale-95 ${
                liveSession.isLive
                  ? 'bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-600/40'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-600/20'
              }`}
            >
              {liveSession.isLive ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              {liveSession.isLive ? 'Pause Session' : 'Resume Session'}
            </button>

            <button
              onClick={() => setIsSimulatingLiveCheckins(!isSimulatingLiveCheckins)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition active:scale-95 ${
                isSimulatingLiveCheckins
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
              }`}
              title="Simulates absent students entering PIN in real-time"
            >
              <Radio className="w-3.5 h-3.5 text-amber-400" />
              {isSimulatingLiveCheckins ? 'Simulating Live Stream (Active)' : 'Simulate Real-time Check-ins'}
            </button>

            <button
              onClick={bulkMarkAllPresent}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-600/40 transition active:scale-95"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              Mark All Present
            </button>

            <button
              onClick={resetSessionAttendance}
              className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition"
            >
              Reset Session
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportCSV}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition active:scale-95"
            >
              <Download className="w-3.5 h-3.5" />
              Export CSV
            </button>
          </div>
        </div>

      </div>

      {/* Gemini AI Attendance Analytics & Retention Insights */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/30 to-slate-900 border border-indigo-900/50 rounded-2xl p-5 shadow-lg">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                Gemini AI Attendance &amp; Retention Analytics
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300">
                  gemini-3.8-flash
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Automated student engagement diagnostics and punctuality recommendations
              </p>
            </div>
          </div>

          <button
            onClick={handleFetchAiInsights}
            disabled={aiLoading}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-semibold shadow-md shadow-indigo-600/30 transition active:scale-95 self-start sm:self-auto"
          >
            {aiLoading ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Sparkles className="w-3.5 h-3.5" />
            )}
            {aiInsights ? 'Refresh Analysis' : 'Run AI Attendance Diagnostics'}
          </button>
        </div>

        {aiInsights && (
          <div className="mt-4 pt-4 border-t border-indigo-900/40 grid grid-cols-1 md:grid-cols-2 gap-4 animate-fade-in text-sm">
            <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs uppercase font-bold text-slate-400 tracking-wider">
                  Cohort Health &amp; Trends
                </span>
                <span className="text-xs font-mono font-bold text-emerald-400">
                  Score: {aiInsights.healthScore || '94%'}
                </span>
              </div>
              <p className="text-xs text-indigo-300 font-semibold mb-2">
                Participation Trend: {aiInsights.trend || 'Stable'}
              </p>
              <ul className="space-y-1.5 text-xs text-slate-300">
                {aiInsights.keyObservations?.map((obs, i) => (
                  <li key={i} className="flex items-start gap-1.5">
                    <span className="text-indigo-400">•</span>
                    <span>{obs}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800">
              <div className="flex items-center gap-1.5 mb-2 text-amber-400 text-xs font-bold uppercase tracking-wider">
                <Lightbulb className="w-3.5 h-3.5" />
                <span>Instructor Action Recommendations</span>
              </div>
              <ul className="space-y-2 text-xs text-slate-300">
                {aiInsights.recommendations?.map((rec, i) => (
                  <li key={i} className="flex items-start gap-2 bg-slate-800/40 p-2 rounded-lg border border-slate-800">
                    <span className="text-amber-400 font-bold shrink-0">{i + 1}.</span>
                    <span>{rec}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </div>

      {/* Student Roll-Call Table & Interactive Real-Time Status Toggle */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
        
        {/* Table Header Filter & Search */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-indigo-400" />
            <h3 className="font-bold text-white text-base">Class Roll Call Roster</h3>
            <span className="text-xs font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
              {filteredStudents.length} / {students.length}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
            {/* Search Input */}
            <div className="relative flex-1 sm:w-56">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search student or ID..."
                className="w-full bg-slate-800/80 border border-slate-700/80 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>

            {/* Status Filter Pills */}
            <div className="flex items-center bg-slate-800/80 p-0.5 rounded-xl border border-slate-700/80 text-xs">
              {(['all', 'present', 'late', 'absent'] as const).map((st) => (
                <button
                  key={st}
                  onClick={() => setFilterStatus(st)}
                  className={`px-2.5 py-1 rounded-lg capitalize font-medium transition ${
                    filterStatus === st
                      ? 'bg-indigo-600 text-white font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Table Content */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-950/60 border-b border-slate-800 text-slate-400 uppercase font-semibold text-[11px] tracking-wider">
                <th className="py-3 px-4">Student</th>
                <th className="py-3 px-4">Student ID</th>
                <th className="py-3 px-4">Overall Rate</th>
                <th className="py-3 px-4">Today's Status</th>
                <th className="py-3 px-4">Check-in Time</th>
                <th className="py-3 px-4">Method</th>
                <th className="py-3 px-4 text-right">Quick Change Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70 text-slate-300">
              {filteredStudents.map((student) => {
                const record = liveSession.records.find((r) => r.studentId === student.id);
                const status = record?.status || 'absent';
                const checkInTime = record?.checkInTime;
                const method = record?.method;

                return (
                  <tr key={student.id} className="hover:bg-slate-800/40 transition">
                    
                    {/* Student Identity */}
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={student.avatar}
                          alt={student.name}
                          className="w-8 h-8 rounded-full object-cover ring-1 ring-slate-700"
                        />
                        <div>
                          <div className="font-semibold text-slate-100">{student.name}</div>
                          <div className="text-[11px] text-slate-400">{student.email}</div>
                        </div>
                      </div>
                    </td>

                    {/* Student ID */}
                    <td className="py-3 px-4 font-mono text-slate-400">
                      {student.studentId}
                    </td>

                    {/* Overall Attendance Rate */}
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <span className={`font-mono font-semibold ${
                          student.attendanceRate >= 90
                            ? 'text-emerald-400'
                            : student.attendanceRate >= 80
                            ? 'text-amber-400'
                            : 'text-rose-400'
                        }`}>
                          {student.attendanceRate}%
                        </span>
                        <span className="text-[10px] text-slate-500">
                          ({student.totalAttended}/{student.totalClasses})
                        </span>
                      </div>
                    </td>

                    {/* Current Today's Status Badge */}
                    <td className="py-3 px-4">
                      {status === 'present' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                          <CheckCircle2 className="w-3 h-3" /> Present
                        </span>
                      )}
                      {status === 'late' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                          <Clock className="w-3 h-3" /> Late
                        </span>
                      )}
                      {status === 'absent' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                          <XCircle className="w-3 h-3" /> Absent
                        </span>
                      )}
                      {status === 'excused' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-sky-500/20 text-sky-300 border border-sky-500/30">
                          Excused
                        </span>
                      )}
                    </td>

                    {/* Check-in Time */}
                    <td className="py-3 px-4 font-mono text-slate-400">
                      {checkInTime || '—'}
                    </td>

                    {/* Method */}
                    <td className="py-3 px-4">
                      {method ? (
                        <span className="inline-block px-2 py-0.5 rounded bg-slate-800 text-[10px] font-mono uppercase text-slate-300 border border-slate-700">
                          {method}
                        </span>
                      ) : (
                        <span className="text-slate-600">—</span>
                      )}
                    </td>

                    {/* Quick 1-Click Status Switcher */}
                    <td className="py-3 px-4 text-right">
                      <div className="inline-flex items-center bg-slate-950/70 p-1 rounded-lg border border-slate-800 gap-1">
                        <button
                          onClick={() => setStudentAttendance(student.id, 'present', 'manual')}
                          title="Mark Present"
                          className={`px-2 py-0.5 rounded text-[10px] font-bold transition ${
                            status === 'present'
                              ? 'bg-emerald-600 text-white shadow-sm'
                              : 'text-slate-400 hover:text-emerald-300'
                          }`}
                        >
                          P
                        </button>
                        <button
                          onClick={() => setStudentAttendance(student.id, 'late', 'manual')}
                          title="Mark Late"
                          className={`px-2 py-0.5 rounded text-[10px] font-bold transition ${
                            status === 'late'
                              ? 'bg-amber-600 text-white shadow-sm'
                              : 'text-slate-400 hover:text-amber-300'
                          }`}
                        >
                          L
                        </button>
                        <button
                          onClick={() => setStudentAttendance(student.id, 'absent', 'manual')}
                          title="Mark Absent"
                          className={`px-2 py-0.5 rounded text-[10px] font-bold transition ${
                            status === 'absent'
                              ? 'bg-rose-600 text-white shadow-sm'
                              : 'text-slate-400 hover:text-rose-300'
                          }`}
                        >
                          A
                        </button>
                        <button
                          onClick={() => setStudentAttendance(student.id, 'excused', 'manual')}
                          title="Mark Excused"
                          className={`px-2 py-0.5 rounded text-[10px] font-bold transition ${
                            status === 'excused'
                              ? 'bg-sky-600 text-white shadow-sm'
                              : 'text-slate-400 hover:text-sky-300'
                          }`}
                        >
                          EX
                        </button>
                      </div>
                    </td>

                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

      </div>

      {/* QR Code Projector Modal */}
      <QRCodeModal
        isOpen={showQR}
        onClose={() => setShowQR(false)}
        pinCode={liveSession.pinCode}
        topic={liveSession.topic}
      />

    </div>
  );
};
