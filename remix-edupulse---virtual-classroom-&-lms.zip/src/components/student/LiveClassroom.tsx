import React, { useState } from 'react';
import { useClass } from '../../context/ClassContext';
import confetti from 'canvas-confetti';
import {
  Radio,
  CheckCircle2,
  AlertCircle,
  ChevronLeft,
  ChevronRight,
  Hand,
  MessageSquare,
  Send,
  Sparkles,
  Mic,
  MicOff,
  Video,
  Monitor,
  Users,
  Clock,
  ShieldCheck,
  Check,
  HelpCircle,
} from 'lucide-react';

export const LiveClassroom: React.FC = () => {
  const {
    liveSession,
    activeStudent,
    checkInWithPin,
    slides,
    currentSlideIndex,
    setCurrentSlideIndex,
    chatMessages,
    sendChatMessage,
    raisedHands,
    toggleRaiseHand,
    showToast,
  } = useClass();

  const [pinInput, setPinInput] = useState('');
  const [chatInput, setChatInput] = useState('');
  const [isQuestion, setIsQuestion] = useState(false);
  const [isMicMuted, setIsMicMuted] = useState(true);
  const [isVideoOn, setIsVideoOn] = useState(false);

  // Check current student's status for this live session
  const studentRecord = liveSession.records.find((r) => r.studentId === activeStudent.id);
  const isPresent = studentRecord?.status === 'present';
  const isLate = studentRecord?.status === 'late';
  const isCheckedIn = isPresent || isLate;
  const isHandRaised = raisedHands.includes(activeStudent.id);

  const currentSlide = slides[currentSlideIndex] || slides[0];

  const handlePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pinInput.trim()) {
      showToast('Please enter the attendance PIN', 'error');
      return;
    }

    const result = checkInWithPin(pinInput);
    if (result.success) {
      showToast(result.message, 'success');
      // Confetti burst on successful attendance check-in!
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });
      setPinInput('');
    } else {
      showToast(result.message, 'error');
    }
  };

  const handleQuickCheckIn = () => {
    const result = checkInWithPin(liveSession.pinCode);
    if (result.success) {
      showToast(result.message, 'success');
      confetti({
        particleCount: 100,
        spread: 80,
        origin: { y: 0.6 },
      });
    } else {
      showToast(result.message, 'error');
    }
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    sendChatMessage(chatInput, isQuestion);
    setChatInput('');
    setIsQuestion(false);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Session Status Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="relative flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-rose-500"></span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30">
                LIVE LECTURE
              </span>
              <span className="text-xs text-slate-400 font-mono">
                {liveSession.startTime} - {liveSession.endTime}
              </span>
            </div>
            <h2 className="text-base sm:text-lg font-bold text-white mt-1">
              {liveSession.topic}
            </h2>
          </div>
        </div>

        {/* Hand Raise & AV Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => toggleRaiseHand()}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold transition active:scale-95 ${
              isHandRaised
                ? 'bg-amber-500 text-slate-950 font-bold shadow-lg shadow-amber-500/20 animate-bounce'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
            }`}
          >
            <Hand className="w-4 h-4" />
            {isHandRaised ? 'Hand Raised ✋' : 'Raise Hand'}
          </button>

          <button
            onClick={() => setIsMicMuted(!isMicMuted)}
            className={`p-2 rounded-xl border transition ${
              isMicMuted
                ? 'bg-slate-800 text-slate-400 border-slate-700 hover:text-slate-200'
                : 'bg-emerald-600 text-white border-emerald-500'
            }`}
            title={isMicMuted ? 'Unmute Microphone' : 'Mute Microphone'}
          >
            {isMicMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>

          <button
            onClick={() => setIsVideoOn(!isVideoOn)}
            className={`p-2 rounded-xl border transition ${
              !isVideoOn
                ? 'bg-slate-800 text-slate-400 border-slate-700 hover:text-slate-200'
                : 'bg-emerald-600 text-white border-emerald-500'
            }`}
            title={isVideoOn ? 'Turn Camera Off' : 'Turn Camera On'}
          >
            <Video className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Classroom Grid: Stage Presentation (Left) + Attendance & Chat (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Stage View: Lecture Presentation Slides */}
        <div className="lg:col-span-8 flex flex-col gap-4">
          
          <div className="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl relative flex flex-col min-h-[460px]">
            
            {/* Stage Presentation Top Bar */}
            <div className="bg-slate-900/90 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Monitor className="w-4 h-4 text-indigo-400" />
                <span className="text-xs font-semibold text-slate-200">
                  Slide {currentSlideIndex + 1} of {slides.length}
                </span>
              </div>

              {/* Slide Navigation Controls */}
              <div className="flex items-center gap-1.5">
                <button
                  disabled={currentSlideIndex === 0}
                  onClick={() => setCurrentSlideIndex(Math.max(0, currentSlideIndex - 1))}
                  className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300 transition"
                  title="Previous Slide"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  disabled={currentSlideIndex === slides.length - 1}
                  onClick={() => setCurrentSlideIndex(Math.min(slides.length - 1, currentSlideIndex + 1))}
                  className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300 transition"
                  title="Next Slide"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Slide Body */}
            <div className="flex-1 p-6 sm:p-10 flex flex-col justify-between bg-gradient-to-b from-slate-950 via-slate-900/60 to-slate-950 text-white">
              <div>
                <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-bold">
                  {currentSlide.subtitle}
                </span>

                <h1 className="text-xl sm:text-2xl lg:text-3xl font-extrabold text-white mt-3 tracking-tight">
                  {currentSlide.title}
                </h1>

                <ul className="mt-6 space-y-3">
                  {currentSlide.bullets.map((bullet, idx) => (
                    <li key={idx} className="flex items-start gap-3 text-sm text-slate-200 leading-relaxed">
                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 mt-2 shrink-0" />
                      <span>{bullet}</span>
                    </li>
                  ))}
                </ul>

                {currentSlide.codeSnippet && (
                  <div className="mt-6 p-4 rounded-xl bg-slate-900 border border-slate-800 font-mono text-xs text-indigo-200 shadow-inner">
                    <pre className="overflow-x-auto">{currentSlide.codeSnippet}</pre>
                  </div>
                )}
              </div>

              {/* Bottom slide footer indicator */}
              <div className="mt-8 pt-4 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500">
                <span>CS302 • Distributed Consensus Protocols</span>
                <span>Instructor: Prof. Sarah Jenkins</span>
              </div>
            </div>

            {/* Floating Instructor WebCam Picture-in-Picture */}
            <div className="absolute bottom-4 right-4 bg-slate-900/90 border border-indigo-500/40 rounded-xl p-2.5 shadow-2xl backdrop-blur-md flex items-center gap-3 w-52 sm:w-60">
              <div className="relative">
                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-amber-500 to-indigo-600 flex items-center justify-center font-bold text-white text-xs">
                  SJ
                </div>
                <div className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-slate-900" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-xs font-bold text-white truncate">Prof. Sarah Jenkins</div>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="text-[10px] text-emerald-400 font-semibold">Speaking</span>
                  {/* Speaking Wave Visualizer */}
                  <div className="flex items-center gap-0.5">
                    <span className="w-0.5 h-2 bg-emerald-400 rounded-full animate-pulse" />
                    <span className="w-0.5 h-3.5 bg-emerald-400 rounded-full animate-bounce" />
                    <span className="w-0.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" />
                  </div>
                </div>
              </div>
            </div>

          </div>

        </div>

        {/* Right Column: Real-Time Attendance Verification & Class Chat */}
        <div className="lg:col-span-4 flex flex-col gap-5">
          
          {/* Attendance Check-in Box */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                <Radio className="w-4 h-4 text-rose-500 animate-pulse" />
                Real-Time Attendance
              </span>
              <span className="text-[11px] font-mono text-slate-400">
                {liveSession.pinExpiresAt}
              </span>
            </div>

            {isCheckedIn ? (
              <div className="bg-emerald-950/40 border border-emerald-600/40 rounded-xl p-4 text-center animate-fade-in">
                <div className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-emerald-500/20 text-emerald-400 mb-2">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h4 className="text-sm font-bold text-emerald-300">
                  {isPresent ? 'Marked Present' : 'Marked Late'}
                </h4>
                <p className="text-xs text-emerald-200/80 mt-1">
                  Checked in at {studentRecord?.checkInTime || '10:02 AM'} via {studentRecord?.method?.toUpperCase() || 'PIN'}.
                </p>
                <div className="mt-3 inline-block text-[11px] font-mono bg-emerald-900/50 px-2 py-0.5 rounded text-emerald-300 border border-emerald-700/50">
                  Session Token: {liveSession.pinCode} Verified
                </div>
              </div>
            ) : (
              <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-4">
                <p className="text-xs text-slate-300 mb-3 leading-relaxed">
                  Enter today's live lecture code announced by Prof. Jenkins to record your attendance.
                </p>

                <form onSubmit={handlePinSubmit} className="space-y-3">
                  <div>
                    <input
                      type="text"
                      value={pinInput}
                      onChange={(e) => setPinInput(e.target.value)}
                      placeholder="e.g. EDU-8492 or 8492"
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-center text-sm font-mono font-bold tracking-wider text-amber-400 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 uppercase"
                    />
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="submit"
                      className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow-md shadow-indigo-600/30 transition active:scale-95"
                    >
                      <Check className="w-4 h-4" />
                      Verify Attendance
                    </button>

                    <button
                      type="button"
                      onClick={handleQuickCheckIn}
                      title="Quick Auto-Checkin"
                      className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition"
                    >
                      1-Tap PIN
                    </button>
                  </div>
                </form>

                <p className="text-[10px] text-slate-500 mt-2 text-center">
                  Live code on instructor screen: <strong className="text-amber-400 font-mono">{liveSession.pinCode}</strong>
                </p>
              </div>
            )}
          </div>

          {/* Live Chat & Q&A Box */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl flex flex-col flex-1 min-h-[320px] shadow-xl overflow-hidden">
            
            <div className="p-3.5 border-b border-slate-800 flex items-center justify-between bg-slate-950/40">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-indigo-400" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  Live Class Q&amp;A &amp; Chat
                </span>
              </div>
              <span className="text-[10px] text-slate-400">
                {chatMessages.length} messages
              </span>
            </div>

            {/* Messages Feed */}
            <div className="flex-1 p-3 overflow-y-auto space-y-2.5 max-h-[260px] text-xs">
              {chatMessages.map((msg) => (
                <div
                  key={msg.id}
                  className={`p-2.5 rounded-xl border leading-relaxed ${
                    msg.isQuestion
                      ? 'bg-amber-950/20 border-amber-900/40 text-amber-200'
                      : msg.senderRole === 'admin'
                      ? 'bg-indigo-950/30 border-indigo-900/40 text-slate-200'
                      : 'bg-slate-800/40 border-slate-800 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between text-[10px] mb-1">
                    <span className="font-bold text-white flex items-center gap-1">
                      {msg.senderName}
                      {msg.senderRole === 'admin' && (
                        <span className="text-[9px] px-1 rounded bg-indigo-500/30 text-indigo-300">
                          Professor
                        </span>
                      )}
                      {msg.isQuestion && (
                        <span className="text-[9px] px-1 rounded bg-amber-500/30 text-amber-300 font-bold">
                          QUESTION
                        </span>
                      )}
                    </span>
                    <span className="text-slate-500 font-mono">{msg.timestamp}</span>
                  </div>
                  <p className="text-[11px]">{msg.text}</p>
                </div>
              ))}
            </div>

            {/* Chat Input */}
            <form onSubmit={handleSendMessage} className="p-3 border-t border-slate-800 bg-slate-950/30">
              <div className="flex items-center justify-between mb-1.5">
                <label className="flex items-center gap-1.5 text-[10px] text-slate-400 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isQuestion}
                    onChange={(e) => setIsQuestion(e.target.checked)}
                    className="rounded bg-slate-800 border-slate-700 text-amber-500 focus:ring-0"
                  />
                  <span>Tag as Question for Professor</span>
                </label>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder="Ask a question or contribute..."
                  className="flex-1 bg-slate-800/90 border border-slate-700/80 rounded-xl px-3 py-1.5 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
                />
                <button
                  type="submit"
                  className="p-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white transition active:scale-95"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </form>

          </div>

        </div>

      </div>

    </div>
  );
};
