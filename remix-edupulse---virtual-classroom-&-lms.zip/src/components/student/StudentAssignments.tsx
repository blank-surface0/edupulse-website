import React, { useState } from 'react';
import { useClass } from '../../context/ClassContext';
import { Assignment, Submission } from '../../types';
import {
  FileCheck2,
  Clock,
  Award,
  Send,
  X,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  FileText,
  Upload,
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const StudentAssignments: React.FC = () => {
  const { assignments, submissions, submitAssignment, activeStudent, showToast } = useClass();

  const [activeSubmitAsg, setActiveSubmitAsg] = useState<Assignment | null>(null);
  const [activeFeedbackSub, setActiveFeedbackSub] = useState<Submission | null>(null);
  const [submissionContent, setSubmissionContent] = useState('');
  const [fileName, setFileName] = useState('');

  const handleOpenSubmit = (asg: Assignment) => {
    const existing = submissions.find((s) => s.assignmentId === asg.id && s.studentId === activeStudent.id);
    setSubmissionContent(existing?.content || '');
    setFileName(existing?.fileName || `${activeStudent.name.toLowerCase().replace(/\s+/g, '_')}_solution.zip`);
    setActiveSubmitAsg(asg);
  };

  const handleConfirmSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeSubmitAsg) return;
    if (!submissionContent.trim()) {
      showToast('Please provide your solution explanation or repository link', 'error');
      return;
    }

    submitAssignment(activeSubmitAsg.id, submissionContent, fileName);
    confetti({
      particleCount: 70,
      spread: 60,
      origin: { y: 0.6 },
    });
    setActiveSubmitAsg(null);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <FileCheck2 className="w-6 h-6 text-indigo-400" />
            Assignments &amp; Submissions
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Submit coursework, track deadline countdowns, and inspect graded instructor &amp; AI feedback.
          </p>
        </div>
      </div>

      {/* Assignments List */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {assignments.map((asg) => {
          const mySubmission = submissions.find(
            (s) => s.assignmentId === asg.id && s.studentId === activeStudent.id
          );
          const isGraded = mySubmission?.status === 'graded';
          const isSubmitted = !!mySubmission;

          return (
            <div
              key={asg.id}
              className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-5 shadow-lg flex flex-col justify-between transition group"
            >
              <div>
                {/* Header status */}
                <div className="flex items-center justify-between gap-2 mb-3">
                  <span
                    className={`text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full ${
                      isGraded
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : isSubmitted
                        ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                        : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    }`}
                  >
                    {isGraded ? 'Graded' : isSubmitted ? 'Submitted' : 'Pending Submission'}
                  </span>

                  <span className="text-xs font-mono font-bold text-amber-400">
                    {asg.totalPoints} pts
                  </span>
                </div>

                <h3 className="text-base font-bold text-white group-hover:text-indigo-300 transition line-clamp-2">
                  {asg.title}
                </h3>
                <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                  {asg.description}
                </p>

                <div className="mt-3 flex items-center gap-1.5 text-xs text-slate-400">
                  <Clock className="w-3.5 h-3.5 text-rose-400" />
                  <span>Due: <strong className="text-slate-300">{asg.dueDate}</strong></span>
                </div>

                {/* Rubric Points Preview */}
                <div className="mt-4 p-2.5 bg-slate-950/60 rounded-xl border border-slate-800 text-[11px] space-y-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                    Rubric Criteria
                  </span>
                  {asg.rubric.slice(0, 2).map((r, i) => (
                    <div key={i} className="flex justify-between text-slate-400">
                      <span className="truncate pr-2">• {r.criteria}</span>
                      <span className="font-mono text-slate-300 shrink-0">{r.points} pts</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Button */}
              <div className="mt-5 pt-4 border-t border-slate-800 flex items-center justify-between">
                {isGraded ? (
                  <div className="flex items-center justify-between w-full">
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-bold block">Score</span>
                      <span className="text-lg font-mono font-bold text-emerald-400">
                        {mySubmission.score} / {asg.totalPoints}
                      </span>
                    </div>
                    <button
                      onClick={() => setActiveFeedbackSub(mySubmission)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-600/40 text-xs font-semibold transition"
                    >
                      <Award className="w-3.5 h-3.5" />
                      View Feedback
                    </button>
                  </div>
                ) : isSubmitted ? (
                  <div className="flex items-center justify-between w-full">
                    <span className="text-xs text-sky-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Under Review
                    </span>
                    <button
                      onClick={() => handleOpenSubmit(asg)}
                      className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition"
                    >
                      Edit Submission
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => handleOpenSubmit(asg)}
                    className="w-full flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/30 transition active:scale-95"
                  >
                    <Send className="w-3.5 h-3.5" />
                    Submit Solution
                  </button>
                )}
              </div>

            </div>
          );
        })}
      </div>

      {/* Submission Modal */}
      {activeSubmitAsg && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-xl w-full p-6 text-white shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setActiveSubmitAsg(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-bold">
              Submitting as {activeStudent.name} ({activeStudent.studentId})
            </span>
            <h3 className="text-lg font-bold text-white mt-1.5">{activeSubmitAsg.title}</h3>
            <p className="text-xs text-slate-400 mt-1">{activeSubmitAsg.description}</p>

            <form onSubmit={handleConfirmSubmit} className="mt-5 space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-bold uppercase tracking-wider mb-1">
                  Solution Text / GitHub Repository / Implementation Notes *
                </label>
                <textarea
                  rows={6}
                  required
                  value={submissionContent}
                  onChange={(e) => setSubmissionContent(e.target.value)}
                  placeholder="Provide your solution breakdown, link to GitHub, and explain key design decisions..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-200 font-mono text-[11px] focus:outline-none focus:border-indigo-500 leading-relaxed"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold uppercase tracking-wider mb-1">
                  Attachment File Name
                </label>
                <div className="flex items-center gap-2">
                  <div className="flex-1 flex items-center bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-200">
                    <FileText className="w-4 h-4 text-indigo-400 mr-2 shrink-0" />
                    <input
                      type="text"
                      value={fileName}
                      onChange={(e) => setFileName(e.target.value)}
                      className="bg-transparent border-none w-full focus:outline-none text-xs text-slate-200 font-mono"
                    />
                  </div>
                  <span className="text-[11px] text-emerald-400 bg-emerald-500/10 px-2.5 py-2 rounded-xl border border-emerald-500/20">
                    Ready
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setActiveSubmitAsg(null)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold shadow-md shadow-indigo-600/30 transition active:scale-95"
                >
                  <Send className="w-3.5 h-3.5" />
                  Turn In Assignment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Graded Feedback Modal */}
      {activeFeedbackSub && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 text-white shadow-2xl relative">
            <button
              onClick={() => setActiveFeedbackSub(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                <Award className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Graded Evaluation</h3>
                <p className="text-xs text-slate-400">Assessed by Instructor &amp; AI Rubric</p>
              </div>
            </div>

            <div className="mt-4 p-4 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
              <span className="text-xs uppercase font-bold text-slate-400 tracking-wider">
                Earned Score
              </span>
              <span className="text-2xl font-mono font-extrabold text-emerald-400">
                {activeFeedbackSub.score} / 100
              </span>
            </div>

            <div className="mt-4 space-y-3 text-xs leading-relaxed">
              <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/60">
                <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block mb-1">
                  Instructor Commentary
                </span>
                <p className="text-slate-200">{activeFeedbackSub.feedback}</p>
              </div>

              {activeFeedbackSub.strengths && activeFeedbackSub.strengths.length > 0 && (
                <div className="bg-emerald-950/20 p-3 rounded-xl border border-emerald-900/40">
                  <span className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider block mb-1">
                    Key Strengths Highlighted
                  </span>
                  <ul className="list-disc pl-4 text-slate-300 text-[11px] space-y-0.5">
                    {activeFeedbackSub.strengths.map((str, i) => (
                      <li key={i}>{str}</li>
                    ))}
                  </ul>
                </div>
              )}

              {activeFeedbackSub.improvements && activeFeedbackSub.improvements.length > 0 && (
                <div className="bg-amber-950/20 p-3 rounded-xl border border-amber-900/40">
                  <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider block mb-1">
                    Growth Opportunities
                  </span>
                  <ul className="list-disc pl-4 text-slate-300 text-[11px] space-y-0.5">
                    {activeFeedbackSub.improvements.map((imp, i) => (
                      <li key={i}>{imp}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            <div className="mt-5 pt-3 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setActiveFeedbackSub(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold transition"
              >
                Close Feedback
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
