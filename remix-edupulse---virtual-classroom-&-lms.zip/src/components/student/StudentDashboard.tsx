import React, { useState } from 'react';
import { useClass } from '../../context/ClassContext';
import { StudentOverview } from './StudentOverview';
import { LiveClassroom } from './LiveClassroom';
import { StudentMaterials } from './StudentMaterials';
import { StudentAssignments } from './StudentAssignments';
import { StudentAttendanceHistory } from './StudentAttendanceHistory';
import { AIStudyBuddy } from './AIStudyBuddy';
import {
  LayoutDashboard,
  Radio,
  BookOpen,
  FileCheck2,
  Calendar,
  Sparkles,
  HelpCircle,
} from 'lucide-react';

interface StudentDashboardProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({ activeTab, setActiveTab }) => {
  const { liveSession, activeStudent } = useClass();
  const [isStudyBuddyOpen, setIsStudyBuddyOpen] = useState(false);

  return (
    <div className="space-y-6">
      
      {/* Student Navigation Sub-bar */}
      <div className="flex items-center justify-between gap-2 overflow-x-auto pb-1 border-b border-slate-800 text-xs">
        <div className="flex items-center gap-1.5 sm:gap-2">
          <button
            onClick={() => setActiveTab('overview')}
            className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-xl font-bold transition whitespace-nowrap ${
              activeTab === 'overview'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/80'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>Dashboard</span>
          </button>

          <button
            onClick={() => setActiveTab('classroom')}
            className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-xl font-bold transition whitespace-nowrap relative ${
              activeTab === 'classroom'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/80'
            }`}
          >
            <Radio className="w-4 h-4 text-rose-400" />
            <span>Live Classroom</span>
            {liveSession.isLive && (
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping ml-1" />
            )}
          </button>

          <button
            onClick={() => setActiveTab('materials')}
            className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-xl font-bold transition whitespace-nowrap ${
              activeTab === 'materials'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/80'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Materials</span>
          </button>

          <button
            onClick={() => setActiveTab('assignments')}
            className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-xl font-bold transition whitespace-nowrap ${
              activeTab === 'assignments'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/80'
            }`}
          >
            <FileCheck2 className="w-4 h-4" />
            <span>Assignments</span>
          </button>

          <button
            onClick={() => setActiveTab('attendance')}
            className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-xl font-bold transition whitespace-nowrap ${
              activeTab === 'attendance'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/80'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>Attendance Log</span>
          </button>
        </div>

        {/* AI Study Assistant Launcher Button */}
        <button
          onClick={() => setIsStudyBuddyOpen(true)}
          className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/20 transition active:scale-95 shrink-0"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Ask AI Study Tutor</span>
          <span className="sm:hidden">AI Tutor</span>
        </button>
      </div>

      {/* Render Active View */}
      {activeTab === 'overview' && (
        <StudentOverview
          onNavigateTab={setActiveTab}
          onOpenStudyBuddy={() => setIsStudyBuddyOpen(true)}
        />
      )}
      {activeTab === 'classroom' && <LiveClassroom />}
      {activeTab === 'materials' && <StudentMaterials />}
      {activeTab === 'assignments' && <StudentAssignments />}
      {activeTab === 'attendance' && <StudentAttendanceHistory />}

      {/* AI Study Buddy Modal */}
      <AIStudyBuddy
        isOpen={isStudyBuddyOpen}
        onClose={() => setIsStudyBuddyOpen(false)}
      />

    </div>
  );
};
