import React from 'react';
import { useClass } from '../../context/ClassContext';
import {
  Calendar,
  CheckCircle2,
  Clock,
  BookOpen,
  FileCheck2,
  AlertTriangle,
  ArrowRight,
  Radio,
  Sparkles,
  Download,
  Eye,
} from 'lucide-react';

interface StudentOverviewProps {
  onNavigateTab: (tab: string) => void;
  onOpenStudyBuddy: () => void;
}

export const StudentOverview: React.FC<StudentOverviewProps> = ({ onNavigateTab, onOpenStudyBuddy }) => {
  const {
    activeStudent,
    liveSession,
    assignments,
    submissions,
    materials,
    checkInWithPin,
    showToast,
  } = useClass();

  // Current session attendance
  const currentAttendance = liveSession.records.find((r) => r.studentId === activeStudent.id);
  const isPresent = currentAttendance?.status === 'present';
  const isLate = currentAttendance?.status === 'late';
  const isCheckedIn = isPresent || isLate;

  const handleQuickCheckin = () => {
    const result = checkInWithPin(liveSession.pinCode);
    if (result.success) {
      showToast(result.message, 'success');
    } else {
      showToast(result.message, 'error');
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Live Class Alert Hero Banner */}
      {liveSession.isLive && (
        <div className="bg-gradient-to-r from-rose-950/60 via-slate-900 to-indigo-950/60 border border-rose-500/40 rounded-2xl p-5 sm:p-6 shadow-2xl relative overflow-hidden">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="p-2.5 rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/30 mt-1">
                <Radio className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300">
                    Live Class Active
                  </span>
                  <span className="text-xs text-slate-400 font-mono">
                    {liveSession.startTime} - {liveSession.endTime}
                  </span>
                </div>
                <h2 className="text-lg sm:text-xl font-bold text-white mt-1">
                  {liveSession.topic}
                </h2>
                <p className="text-xs text-slate-300 mt-1">
                  Prof. Sarah Jenkins is presenting live slides and conducting roll call.
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              {!isCheckedIn ? (
                <button
                  onClick={handleQuickCheckin}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold shadow-lg shadow-amber-500/20 transition active:scale-95"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  Quick Check-In ({liveSession.pinCode})
                </button>
              ) : (
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs font-semibold">
                  <CheckCircle2 className="w-4 h-4" />
                  Checked In (Present)
                </div>
              )}

              <button
                onClick={() => onNavigateTab('classroom')}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/30 transition active:scale-95"
              >
                Join Live Classroom
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* KPI Cards: Attendance, Assignments, Learning Resources */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* Attendance Rate Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
              <span className="font-semibold uppercase tracking-wider">Attendance Health</span>
              <Clock className="w-4 h-4 text-emerald-400" />
            </div>
            
            <div className="flex items-baseline gap-2">
              <span className={`text-3xl font-extrabold font-mono ${
                activeStudent.attendanceRate >= 90
                  ? 'text-emerald-400'
                  : activeStudent.attendanceRate >= 80
                  ? 'text-amber-400'
                  : 'text-rose-400'
              }`}>
                {activeStudent.attendanceRate}%
              </span>
              <span className="text-xs text-slate-400">
                ({activeStudent.totalAttended} of {activeStudent.totalClasses} classes)
              </span>
            </div>

            <div className="w-full bg-slate-800 rounded-full h-2 mt-3 overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  activeStudent.attendanceRate >= 90
                    ? 'bg-emerald-500'
                    : activeStudent.attendanceRate >= 80
                    ? 'bg-amber-500'
                    : 'bg-rose-500'
                }`}
                style={{ width: `${activeStudent.attendanceRate}%` }}
              />
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
            <span className="text-slate-400">
              {isCheckedIn ? 'Checked in for today' : 'Today: Needs Check-in'}
            </span>
            <button
              onClick={() => onNavigateTab('attendance')}
              className="text-indigo-400 hover:text-indigo-300 font-semibold"
            >
              View History →
            </button>
          </div>
        </div>

        {/* Assignments Progress Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
              <span className="font-semibold uppercase tracking-wider">Assignments</span>
              <FileCheck2 className="w-4 h-4 text-indigo-400" />
            </div>

            {(() => {
              const mySubmissions = submissions.filter((s) => s.studentId === activeStudent.id);
              const submittedCount = mySubmissions.length;
              const pendingCount = assignments.filter((a) => a.status === 'active' && !mySubmissions.some((s) => s.assignmentId === a.id)).length;

              return (
                <div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-extrabold text-white font-mono">
                      {submittedCount} / {assignments.length}
                    </span>
                    <span className="text-xs text-slate-400">Completed</span>
                  </div>
                  <p className="text-xs text-indigo-300 mt-2">
                    {pendingCount > 0 ? `${pendingCount} assignment(s) awaiting your submission` : 'All published assignments submitted!'}
                  </p>
                </div>
              );
            })()}
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
            <span className="text-slate-400">Term Average: 96%</span>
            <button
              onClick={() => onNavigateTab('assignments')}
              className="text-indigo-400 hover:text-indigo-300 font-semibold"
            >
              View Tasks →
            </button>
          </div>
        </div>

        {/* AI Study Companion Card */}
        <div className="bg-gradient-to-br from-indigo-950/40 to-slate-900 border border-indigo-500/30 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-indigo-300 mb-2">
              <span className="font-semibold uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-indigo-400" />
                AI Study Tutor
              </span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300">
                gemini-3.1-flash-lite
              </span>
            </div>

            <h3 className="text-sm font-bold text-white mt-1">24/7 Course Assistant</h3>
            <p className="text-xs text-slate-300 mt-1 leading-relaxed">
              Ask questions on lecture slides, clarify distributed systems concepts, or get assignment hints.
            </p>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800">
            <button
              onClick={onOpenStudyBuddy}
              className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/30 transition active:scale-95"
            >
              <Sparkles className="w-3.5 h-3.5" />
              Ask Study Assistant
            </button>
          </div>
        </div>

      </div>

      {/* Two Column Section: Active Assignments + Recent Course Materials */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Active Assignments */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <FileCheck2 className="w-5 h-5 text-indigo-400" />
              Current Assignments
            </h3>
            <button
              onClick={() => onNavigateTab('assignments')}
              className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold"
            >
              See All
            </button>
          </div>

          <div className="space-y-3">
            {assignments.slice(0, 3).map((asg) => {
              const mySub = submissions.find((s) => s.assignmentId === asg.id && s.studentId === activeStudent.id);

              return (
                <div
                  key={asg.id}
                  className="bg-slate-800/40 border border-slate-800 rounded-xl p-3.5 flex items-center justify-between gap-3 hover:border-slate-700 transition"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
                        {asg.totalPoints} pts
                      </span>
                      <span className="text-xs text-slate-400 truncate">{asg.dueDate}</span>
                    </div>
                    <h4 className="text-xs font-bold text-white truncate">{asg.title}</h4>
                  </div>

                  <div>
                    {mySub ? (
                      mySub.status === 'graded' ? (
                        <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded-lg border border-emerald-500/20">
                          {mySub.score}/{asg.totalPoints} pts
                        </span>
                      ) : (
                        <span className="text-xs font-semibold text-sky-400 bg-sky-500/10 px-2 py-1 rounded-lg border border-sky-500/20">
                          Submitted
                        </span>
                      )
                    ) : (
                      <button
                        onClick={() => onNavigateTab('assignments')}
                        className="px-3 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition active:scale-95"
                      >
                        Submit
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recent Course Materials */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-indigo-400" />
              Latest Learning Materials
            </h3>
            <button
              onClick={() => onNavigateTab('materials')}
              className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold"
            >
              Browse Library
            </button>
          </div>

          <div className="space-y-3">
            {materials.slice(0, 3).map((mat) => (
              <div
                key={mat.id}
                className="bg-slate-800/40 border border-slate-800 rounded-xl p-3.5 flex items-center justify-between gap-3 hover:border-slate-700 transition"
              >
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-semibold">
                      {mat.category}
                    </span>
                    <span className="text-xs text-slate-400">Week {mat.week}</span>
                  </div>
                  <h4 className="text-xs font-bold text-white truncate">{mat.title}</h4>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => onNavigateTab('materials')}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                    title="View Material"
                  >
                    <Eye className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => showToast(`Downloaded ${mat.title}`, 'success')}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                    title="Download"
                  >
                    <Download className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
