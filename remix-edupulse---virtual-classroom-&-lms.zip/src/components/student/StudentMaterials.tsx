import React, { useState } from 'react';
import { useClass } from '../../context/ClassContext';
import { CourseMaterial, MaterialCategory } from '../../types';
import {
  FolderOpen,
  Search,
  FileText,
  Code,
  Video,
  FileCheck,
  BookOpen,
  Eye,
  Download,
  X,
} from 'lucide-react';

export const StudentMaterials: React.FC = () => {
  const { materials, incrementMaterialViews, showToast } = useClass();
  const [search, setSearch] = useState('');
  const [selectedCat, setSelectedCat] = useState<string>('all');
  const [previewMaterial, setPreviewMaterial] = useState<CourseMaterial | null>(null);

  const filtered = materials.filter((m) => {
    const matchSearch =
      m.title.toLowerCase().includes(search.toLowerCase()) ||
      m.description.toLowerCase().includes(search.toLowerCase()) ||
      m.module.toLowerCase().includes(search.toLowerCase());
    const matchCat = selectedCat === 'all' || m.category === selectedCat;
    return matchSearch && matchCat;
  });

  const getCategoryIcon = (cat: MaterialCategory) => {
    switch (cat) {
      case 'slides':
        return <FileText className="w-5 h-5 text-indigo-400" />;
      case 'code':
        return <Code className="w-5 h-5 text-emerald-400" />;
      case 'video':
        return <Video className="w-5 h-5 text-rose-400" />;
      case 'cheatsheet':
        return <FileCheck className="w-5 h-5 text-amber-400" />;
      default:
        return <BookOpen className="w-5 h-5 text-sky-400" />;
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <FolderOpen className="w-6 h-6 text-indigo-400" />
            Course Materials &amp; Study Library
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Access lecture slides, supplementary reading, runnable reference code, and video recordings.
          </p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-900/60 border border-slate-800 p-3 rounded-xl">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search slides, topics, or modules..."
            className="w-full bg-slate-800/80 border border-slate-700/80 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>

        <div className="flex items-center gap-1 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0 text-xs">
          {[
            { id: 'all', label: 'All Files' },
            { id: 'slides', label: 'Slides' },
            { id: 'reading', label: 'Readings' },
            { id: 'notes', label: 'Notes' },
            { id: 'code', label: 'Code' },
            { id: 'cheatsheet', label: 'Cheatsheets' },
            { id: 'video', label: 'Videos' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCat(cat.id)}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap capitalize font-medium transition ${
                selectedCat === cat.id
                  ? 'bg-indigo-600 text-white font-semibold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Materials Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((mat) => (
          <div
            key={mat.id}
            className="bg-slate-900 border border-slate-800 hover:border-slate-700/80 rounded-2xl p-5 shadow-lg flex flex-col justify-between transition group"
          >
            <div>
              <div className="flex items-center justify-between gap-2 mb-2">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-slate-800 border border-slate-700/60">
                    {getCategoryIcon(mat.category)}
                  </div>
                  <div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 uppercase font-semibold">
                      {mat.category}
                    </span>
                    <span className="text-[11px] text-slate-400 ml-2 font-mono">Week {mat.week}</span>
                  </div>
                </div>

                <div className="text-[11px] text-slate-500 font-mono">
                  {mat.fileSize}
                </div>
              </div>

              <h3 className="text-base font-bold text-white group-hover:text-indigo-300 transition line-clamp-1">
                {mat.title}
              </h3>
              <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                {mat.description}
              </p>

              <div className="mt-2 text-[11px] text-indigo-400 font-medium">
                {mat.module}
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-slate-800/80 flex items-center justify-between">
              <span className="text-[11px] text-slate-500">{mat.fileType}</span>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    incrementMaterialViews(mat.id);
                    setPreviewMaterial(mat);
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition"
                >
                  <Eye className="w-3.5 h-3.5" />
                  Read Online
                </button>

                <button
                  onClick={() => showToast(`Downloaded ${mat.title}`, 'success')}
                  className="p-1.5 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-600/40 transition"
                  title="Download File"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

          </div>
        ))}
      </div>

      {/* Reader Modal */}
      {previewMaterial && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full p-6 text-white shadow-2xl relative max-h-[85vh] flex flex-col">
            <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-800">
              <div>
                <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-bold">
                  {previewMaterial.category} • Week {previewMaterial.week}
                </span>
                <h3 className="text-lg font-bold text-white mt-1.5">{previewMaterial.title}</h3>
                <p className="text-xs text-slate-400">{previewMaterial.module}</p>
              </div>
              <button
                onClick={() => setPreviewMaterial(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="py-4 overflow-y-auto space-y-4 text-xs leading-relaxed text-slate-300">
              <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/60">
                <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                  Resource Overview
                </div>
                <p>{previewMaterial.description}</p>
              </div>

              {previewMaterial.content && (
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 font-mono text-[11px] whitespace-pre-wrap text-slate-200">
                  {previewMaterial.content}
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
              <span className="text-[11px] text-slate-500">{previewMaterial.fileType} • {previewMaterial.fileSize}</span>
              <button
                onClick={() => {
                  showToast(`Downloaded ${previewMaterial.title}`, 'success');
                  setPreviewMaterial(null);
                }}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition"
              >
                <Download className="w-3.5 h-3.5" />
                Download Attachment
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
