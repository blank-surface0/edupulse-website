import React from 'react';
import { useClass } from '../../context/ClassContext';
import {
  Calendar,
  CheckCircle2,
  Clock,
  XCircle,
  ShieldCheck,
  AlertCircle,
  Download,
} from 'lucide-react';

export const StudentAttendanceHistory: React.FC = () => {
  const { activeStudent, liveSession, showToast } = useClass();

  // Find record in today's live session
  const todayRecord = liveSession.records.find((r) => r.studentId === activeStudent.id);
  const todayStatus = todayRecord?.status || 'absent';

  // Historical sessions
  const historicalSessions = [
    {
      id: 'h-1',
      date: 'Today (Nov 07)',
      topic: liveSession.topic,
      status: todayStatus,
      time: todayRecord?.checkInTime || (todayStatus === 'present' ? '10:02 AM' : '—'),
      method: todayRecord?.method?.toUpperCase() || (todayStatus === 'present' ? 'PIN' : '—'),
      isLive: true,
    },
    {
      id: 'h-2',
      date: 'Nov 05, 2026',
      topic: 'Lecture 11: High-Throughput Event Streaming with Kafka & Raft',
      status: 'present',
      time: '10:01 AM',
      method: 'PIN',
    },
    {
      id: 'h-3',
      date: 'Nov 02, 2026',
      topic: 'Lecture 10: PACELC & CAP Theorem In Production Systems',
      status: 'present',
      time: '10:04 AM',
      method: 'PIN',
    },
    {
      id: 'h-4',
      date: 'Oct 29, 2026',
      topic: 'Lecture 09: Storage Engine Compaction (LSM Trees vs B+ Trees)',
      status: 'late',
      time: '10:19 AM',
      method: 'MANUAL',
    },
    {
      id: 'h-5',
      date: 'Oct 26, 2026',
      topic: 'Lecture 08: Consistent Hashing & Ring Partitioning',
      status: 'present',
      time: '10:00 AM',
      method: 'QR',
    },
    {
      id: 'h-6',
      date: 'Oct 22, 2026',
      topic: 'Lecture 07: Vector Clocks & Causal Dependency Tracking',
      status: 'present',
      time: '10:03 AM',
      method: 'PIN',
    },
    {
      id: 'h-7',
      date: 'Oct 19, 2026',
      topic: 'Lecture 06: RPC Serialization, gRPC & Protocol Buffers',
      status: 'present',
      time: '10:02 AM',
      method: 'PIN',
    },
  ];

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Calendar className="w-6 h-6 text-indigo-400" />
            Personal Attendance Ledger
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Official record for <strong className="text-slate-200">{activeStudent.name}</strong> ({activeStudent.studentId}).
          </p>
        </div>

        <button
          onClick={() => showToast('Attendance transcript exported', 'success')}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition"
        >
          <Download className="w-3.5 h-3.5" />
          Download Transcript
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
          <span className="text-xs text-slate-400">Total Lectures</span>
          <div className="text-2xl font-bold text-white font-mono mt-1">
            {activeStudent.totalClasses}
          </div>
          <span className="text-[10px] text-slate-500">Term total</span>
        </div>

        <div className="bg-emerald-950/20 border border-emerald-900/40 p-4 rounded-xl">
          <span className="text-xs text-emerald-400">Attended (Present)</span>
          <div className="text-2xl font-bold text-emerald-300 font-mono mt-1">
            {activeStudent.totalAttended}
          </div>
          <span className="text-[10px] text-emerald-400/80">Verified sessions</span>
        </div>

        <div className="bg-amber-950/20 border border-amber-900/40 p-4 rounded-xl">
          <span className="text-xs text-amber-400">Late Check-Ins</span>
          <div className="text-2xl font-bold text-amber-300 font-mono mt-1">1</div>
          <span className="text-[10px] text-amber-400/80">&gt; 15 mins post-start</span>
        </div>

        <div className="bg-indigo-950/30 border border-indigo-900/40 p-4 rounded-xl">
          <span className="text-xs text-indigo-300">Compliance Rate</span>
          <div className="text-2xl font-bold text-indigo-400 font-mono mt-1">
            {activeStudent.attendanceRate}%
          </div>
          <span className="text-[10px] text-indigo-300/80">Minimum required: 80%</span>
        </div>
      </div>

      {/* History Ledger Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <h3 className="font-bold text-white text-sm">Session-by-Session History</h3>
          <span className="text-xs text-slate-400">Showing last 7 sessions</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-950/60 border-b border-slate-800 text-slate-400 uppercase font-semibold text-[11px] tracking-wider">
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Lecture / Topic</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Arrival Time</th>
                <th className="py-3 px-4">Verification</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70 text-slate-300">
              {historicalSessions.map((session) => (
                <tr key={session.id} className="hover:bg-slate-800/40 transition">
                  <td className="py-3 px-4 font-mono font-medium text-slate-200">
                    {session.date}
                  </td>
                  <td className="py-3 px-4 font-semibold text-slate-100">
                    {session.topic}
                  </td>
                  <td className="py-3 px-4">
                    {session.status === 'present' && (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                        <CheckCircle2 className="w-3 h-3" /> Present
                      </span>
                    )}
                    {session.status === 'late' && (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                        <Clock className="w-3 h-3" /> Late
                      </span>
                    )}
                    {session.status === 'absent' && (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                        <XCircle className="w-3 h-3" /> Absent
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-400">
                    {session.time}
                  </td>
                  <td className="py-3 px-4">
                    <span className="inline-block px-2 py-0.5 rounded bg-slate-800 text-[10px] font-mono uppercase text-slate-300 border border-slate-700">
                      {session.method}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
