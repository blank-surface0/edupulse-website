import React, { useState } from 'react';
import { useClass } from '../../context/ClassContext';
import {
  Sparkles,
  Send,
  X,
  RefreshCw,
  BookOpen,
  HelpCircle,
  Lightbulb,
  ArrowRight,
} from 'lucide-react';

interface AIStudyBuddyProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AIStudyBuddy: React.FC<AIStudyBuddyProps> = ({ isOpen, onClose }) => {
  const { liveSession, materials, assignments } = useClass();

  const [inputQuery, setInputQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<
    Array<{ sender: 'user' | 'ai'; text: string; related?: string[] }>
  >([
    {
      sender: 'ai',
      text: `Hello! I'm your AI Course Assistant for **${liveSession.courseName}**. How can I help you with today's lecture on **${liveSession.topic}** or your active assignments?`,
      related: [
        'Why do Raft nodes use randomized election timeouts?',
        'What is the difference between CAP and PACELC?',
        'Can you give me an architecture hint for Assignment 3?',
      ],
    },
  ]);

  if (!isOpen) return null;

  const handleSend = async (queryText?: string) => {
    const textToSend = queryText || inputQuery;
    if (!textToSend.trim() || loading) return;

    // Add user message
    setMessages((prev) => [...prev, { sender: 'user', text: textToSend }]);
    setInputQuery('');
    setLoading(true);

    try {
      const res = await fetch('/api/gemini/study-assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: textToSend,
          context: {
            course: liveSession.courseName,
            topic: liveSession.topic,
            activeAssignment: assignments[0]?.title,
          },
          history: messages.slice(-4),
        }),
      });

      const data = await res.json();
      if (data.error) throw new Error(data.error);

      setMessages((prev) => [
        ...prev,
        {
          sender: 'ai',
          text: data.answer || 'Here is the explanation for your inquiry.',
          related: data.relatedQuestions || [],
        },
      ]);
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          sender: 'ai',
          text: 'I encountered an issue connecting to the Gemini reasoning engine. Please ensure your query is formulated clearly.',
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="bg-slate-900 border border-indigo-500/40 rounded-2xl max-w-2xl w-full h-[85vh] text-white shadow-2xl flex flex-col overflow-hidden relative">
        
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                Gemini AI Study Companion
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300">
                  gemini-3.1-flash-lite
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Contextual tutor grounded in CS302 lectures and assignments
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Chat History Feed */}
        <div className="flex-1 p-4 overflow-y-auto space-y-4 text-xs leading-relaxed">
          {messages.map((msg, i) => (
            <div
              key={i}
              className={`flex flex-col ${
                msg.sender === 'user' ? 'items-end' : 'items-start'
              }`}
            >
              <div
                className={`max-w-[85%] p-3.5 rounded-2xl whitespace-pre-wrap ${
                  msg.sender === 'user'
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                    : 'bg-slate-800/80 border border-slate-700/80 text-slate-200 shadow-sm'
                }`}
              >
                {msg.text}
              </div>

              {/* Suggested Follow-up Questions */}
              {msg.related && msg.related.length > 0 && (
                <div className="mt-2 space-y-1.5 max-w-[85%]">
                  <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                    Suggested Explorations:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {msg.related.map((rq, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleSend(rq)}
                        className="text-left text-[11px] px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-indigo-600/30 text-indigo-300 border border-slate-700/60 hover:border-indigo-500/40 transition active:scale-95 flex items-center gap-1"
                      >
                        <ArrowRight className="w-3 h-3 text-indigo-400 shrink-0" />
                        <span>{rq}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-2 text-indigo-400 text-xs py-2">
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>Gemini is generating educational explanation...</span>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="p-3 border-t border-slate-800 bg-slate-950/40"
        >
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              placeholder="Ask anything about the lecture, Raft consensus, or assignments..."
              className="flex-1 bg-slate-800/90 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
            />
            <button
              type="submit"
              disabled={loading || !inputQuery.trim()}
              className="p-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-semibold transition active:scale-95 shadow-md shadow-indigo-600/20"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
