import React, { useState } from 'react';
import { useClass } from '../context/ClassContext';
import {
  GraduationCap,
  ShieldCheck,
  UserCheck,
  Radio,
  ChevronDown,
  Sparkles,
  BookOpen,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentTab, setCurrentTab }) => {
  const {
    role,
    setRole,
    activeStudent,
    setActiveStudent,
    students,
    liveSession,
    showToast,
  } = useClass();

  const [studentDropdownOpen, setStudentDropdownOpen] = useState(false);

  // Current student's attendance in today's live session
  const currentAttendance = liveSession.records.find((r) => r.studentId === activeStudent.id);
  const isPresent = currentAttendance?.status === 'present';
  const isLate = currentAttendance?.status === 'late';

  const handleRoleChange = (newRole: 'admin' | 'student') => {
    setRole(newRole);
    if (newRole === 'admin') {
      showToast('Switched to Instructor Admin Panel (Full Access)', 'info');
    } else {
      showToast(`Switched to Student Portal (${activeStudent.name})`, 'info');
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-900/90 border-b border-slate-800 backdrop-blur-md text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Logo & Course Info */}
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-500 shadow-md shadow-indigo-500/20">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold tracking-tight text-lg bg-gradient-to-r from-white via-slate-100 to-indigo-200 bg-clip-text text-transparent">
                  EduPulse
                </span>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  LMS + LIVE
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block truncate max-w-xs md:max-w-md">
                CS302: Cloud Architecture &amp; Distributed Systems
              </p>
            </div>
          </div>

          {/* Center: Live Session Banner */}
          {liveSession.isLive && (
            <button
              onClick={() => {
                if (role === 'admin') {
                  setCurrentTab('attendance');
                } else {
                  setCurrentTab('classroom');
                }
              }}
              className="hidden lg:flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-rose-500/10 border border-rose-500/30 text-rose-300 hover:bg-rose-500/20 transition-all text-xs font-semibold group cursor-pointer"
            >
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
              </span>
              <span className="group-hover:text-rose-200">
                {role === 'admin' ? 'Class in Session: Live Roll Call Active' : 'Lecture 12 is LIVE • Join Classroom'}
              </span>
              <span className="font-mono bg-rose-950/60 text-rose-300 px-1.5 py-0.5 rounded text-[11px] border border-rose-700/50">
                PIN: {liveSession.pinCode}
              </span>
            </button>
          )}

          {/* Right: Role Switcher & User Profile */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Student Attendance Pill (Only visible in Student view) */}
            {role === 'student' && (
              <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium border bg-slate-800/80">
                {isPresent ? (
                  <span className="text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Checked In (Present)
                  </span>
                ) : isLate ? (
                  <span className="text-amber-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Checked In (Late)
                  </span>
                ) : (
                  <span className="text-amber-400 flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5" /> Attendance Pending
                  </span>
                )}
              </div>
            )}

            {/* Role Toggle Switch */}
            <div className="bg-slate-800/90 p-1 rounded-xl border border-slate-700/80 flex items-center shadow-inner">
              <button
                onClick={() => handleRoleChange('admin')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  role === 'admin'
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Admin</span> Panel
              </button>

              <button
                onClick={() => handleRoleChange('student')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  role === 'student'
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <UserCheck className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Student</span> Portal
              </button>
            </div>

            {/* User Dropdown / Switcher */}
            {role === 'student' ? (
              <div className="relative">
                <button
                  onClick={() => setStudentDropdownOpen(!studentDropdownOpen)}
                  className="flex items-center gap-2 px-2 py-1.5 rounded-xl hover:bg-slate-800 border border-slate-700/60 transition"
                  title="Switch Student Account"
                >
                  <img
                    src={activeStudent.avatar}
                    alt={activeStudent.name}
                    className="w-7 h-7 rounded-full object-cover ring-2 ring-indigo-500/40"
                  />
                  <div className="text-left hidden sm:block">
                    <div className="text-xs font-medium leading-none text-slate-200 truncate max-w-[100px]">
                      {activeStudent.name}
                    </div>
                    <div className="text-[10px] text-slate-400 leading-none mt-1">Student</div>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                </button>

                {studentDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-64 bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl py-2 z-50 text-white animate-fade-in">
                    <div className="px-3 py-2 border-b border-slate-800">
                      <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                        Switch Student Profile
                      </p>
                    </div>
                    <div className="max-h-60 overflow-y-auto py-1">
                      {students.map((student) => (
                        <button
                          key={student.id}
                          onClick={() => {
                            setActiveStudent(student);
                            setStudentDropdownOpen(false);
                          }}
                          className={`w-full flex items-center justify-between px-3 py-2 text-left hover:bg-slate-800 transition ${
                            activeStudent.id === student.id ? 'bg-indigo-600/15 text-indigo-300 font-semibold' : 'text-slate-300'
                          }`}
                        >
                          <div className="flex items-center gap-2.5">
                            <img
                              src={student.avatar}
                              alt={student.name}
                              className="w-6 h-6 rounded-full object-cover"
                            />
                            <div>
                              <div className="text-xs">{student.name}</div>
                              <div className="text-[10px] text-slate-400">{student.studentId}</div>
                            </div>
                          </div>
                          <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${
                            student.attendanceRate >= 90
                              ? 'bg-emerald-500/20 text-emerald-300'
                              : 'bg-amber-500/20 text-amber-300'
                          }`}>
                            {student.attendanceRate}%
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl bg-slate-800/80 border border-slate-700/60">
                <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-amber-500 to-indigo-600 flex items-center justify-center text-xs font-bold text-white shadow-sm">
                  SJ
                </div>
                <div className="text-left hidden sm:block">
                  <div className="text-xs font-medium leading-none text-slate-200">Prof. Sarah Jenkins</div>
                  <div className="text-[10px] text-amber-400 leading-none mt-1 font-semibold">Course Administrator</div>
                </div>
              </div>
            )}

          </div>

        </div>
      </div>
    </header>
  );
};
