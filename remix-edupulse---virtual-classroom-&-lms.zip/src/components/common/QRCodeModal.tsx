import React from 'react';
import { X, QrCode, Copy, Check, Sparkles } from 'lucide-react';
import { useState } from 'react';

interface QRCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
  pinCode: string;
  topic: string;
}

export const QRCodeModal: React.FC<QRCodeModalProps> = ({ isOpen, onClose, pinCode, topic }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(pinCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl p-6 sm:p-8 max-w-sm w-full text-center relative shadow-2xl text-white">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 mb-4">
          <QrCode className="w-6 h-6" />
        </div>

        <h3 className="text-xl font-bold tracking-tight text-slate-100">Live Attendance Code</h3>
        <p className="text-xs text-slate-400 mt-1 line-clamp-1">{topic}</p>

        {/* Projected QR Simulation Box */}
        <div className="my-6 p-5 bg-white rounded-xl mx-auto inline-block shadow-inner">
          <svg className="w-48 h-48 mx-auto" viewBox="0 0 100 100">
            {/* Corner Markers */}
            <rect x="5" y="5" width="28" height="28" fill="#0f172a" rx="4" />
            <rect x="9" y="9" width="20" height="20" fill="white" rx="2" />
            <rect x="13" y="13" width="12" height="12" fill="#0f172a" rx="2" />

            <rect x="67" y="5" width="28" height="28" fill="#0f172a" rx="4" />
            <rect x="71" y="9" width="20" height="20" fill="white" rx="2" />
            <rect x="75" y="13" width="12" height="12" fill="#0f172a" rx="2" />

            <rect x="5" y="67" width="28" height="28" fill="#0f172a" rx="4" />
            <rect x="9" y="71" width="20" height="20" fill="white" rx="2" />
            <rect x="13" y="75" width="12" height="12" fill="#0f172a" rx="2" />

            {/* Simulated Data Grid */}
            <rect x="38" y="10" width="8" height="8" fill="#0f172a" />
            <rect x="50" y="12" width="6" height="6" fill="#0f172a" />
            <rect x="42" y="24" width="8" height="8" fill="#0f172a" />
            <rect x="12" y="42" width="6" height="6" fill="#0f172a" />
            <rect x="22" y="48" width="8" height="8" fill="#0f172a" />
            <rect x="36" y="38" width="10" height="10" fill="#6366f1" />
            <rect x="52" y="40" width="8" height="8" fill="#0f172a" />
            <rect x="64" y="48" width="8" height="8" fill="#0f172a" />
            <rect x="78" y="40" width="6" height="6" fill="#0f172a" />
            <rect x="40" y="54" width="6" height="6" fill="#0f172a" />
            <rect x="52" y="56" width="10" height="10" fill="#6366f1" />
            <rect x="70" y="66" width="8" height="8" fill="#0f172a" />
            <rect x="42" y="72" width="8" height="8" fill="#0f172a" />
            <rect x="56" y="78" width="6" height="6" fill="#0f172a" />
            <rect x="80" y="80" width="10" height="10" fill="#0f172a" />
          </svg>
        </div>

        <div className="bg-slate-800/80 rounded-xl p-3 border border-slate-700 flex items-center justify-between">
          <div className="text-left">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">PIN Code</span>
            <div className="text-xl font-mono font-bold text-amber-400 tracking-wider">{pinCode}</div>
          </div>
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold text-white transition active:scale-95"
          >
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? 'Copied' : 'Copy'}
          </button>
        </div>

        <div className="mt-4 flex items-center justify-center gap-1.5 text-xs text-emerald-400">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Real-time verification active for all students</span>
        </div>
      </div>
    </div>
  );
};
