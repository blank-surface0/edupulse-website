import React, { useState } from 'react';
import { ClassProvider, useClass } from './context/ClassContext';
import { Navbar } from './components/Navbar';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { StudentDashboard } from './components/student/StudentDashboard';
import { ToastContainer } from './components/common/ToastContainer';
import { ShieldCheck, UserCheck, GraduationCap } from 'lucide-react';

function MainApp() {
  const { role, setRole, activeStudent } = useClass();
  const [adminTab, setAdminTab] = useState('attendance');
  const [studentTab, setStudentTab] = useState('overview');

  const currentTab = role === 'admin' ? adminTab : studentTab;
  const setCurrentTab = (tab: string) => {
    if (role === 'admin') {
      setAdminTab(tab);
    } else {
      setStudentTab(tab);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Top Navbar */}
      <Navbar currentTab={currentTab} setCurrentTab={setCurrentTab} />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {role === 'admin' ? (
          <AdminDashboard activeTab={adminTab} setActiveTab={setAdminTab} />
        ) : (
          <StudentDashboard activeTab={studentTab} setActiveTab={setStudentTab} />
        )}
      </main>

      {/* Floating Role Quick Switcher (Bottom Left) */}
      <div className="fixed bottom-5 left-5 z-40 hidden sm:flex items-center bg-slate-900/90 border border-slate-700/80 rounded-2xl p-1.5 shadow-2xl backdrop-blur-md">
        <span className="text-[11px] font-bold text-slate-400 px-2.5">
          Role:
        </span>
        <button
          onClick={() => setRole('admin')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
            role === 'admin'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5" />
          Admin (Prof. Jenkins)
        </button>
        <button
          onClick={() => setRole('student')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
            role === 'student'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <UserCheck className="w-3.5 h-3.5" />
          Student ({activeStudent.name.split(' ')[0]})
        </button>
      </div>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <GraduationCap className="w-4 h-4 text-indigo-400" />
            <span className="font-semibold text-slate-400">EduPulse Learning Management &amp; Virtual Classroom</span>
          </div>
          <p className="text-[11px] text-slate-500">
            Real-Time Attendance Engine • Powered by Google Gemini 3.8 Flash &amp; Flash-Lite
          </p>
        </div>
      </footer>

      {/* Global Notifications */}
      <ToastContainer />
    </div>
  );
}

export default function App() {
  return (
    <ClassProvider>
      <MainApp />
    </ClassProvider>
  );
}
