export type Role = 'admin' | 'student';

export type AttendanceStatus = 'present' | 'late' | 'absent' | 'excused';

export interface Student {
  id: string;
  name: string;
  email: string;
  avatar: string;
  studentId: string;
  attendanceRate: number; // e.g. 92
  totalAttended: number;
  totalClasses: number;
  lastActive?: string;
  notes?: string;
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  studentName: string;
  studentAvatar: string;
  status: AttendanceStatus;
  checkInTime?: string;
  method?: 'pin' | 'manual' | 'qr' | 'facial';
  notes?: string;
}

export interface AttendanceSession {
  id: string;
  courseId: string;
  courseName: string;
  topic: string;
  date: string;
  startTime: string;
  endTime: string;
  isLive: boolean;
  pinCode: string;
  pinExpiresAt?: string;
  records: AttendanceRecord[];
}

export type MaterialCategory = 'slides' | 'notes' | 'code' | 'video' | 'cheatsheet' | 'reading';

export interface CourseMaterial {
  id: string;
  title: string;
  description: string;
  category: MaterialCategory;
  module: string;
  week: number;
  fileType: string;
  fileSize?: string;
  downloadUrl?: string;
  content?: string; // Rich text / markdown content
  isAiGenerated?: boolean;
  uploadedAt: string;
  views: number;
}

export interface RubricItem {
  criteria: string;
  points: number;
}

export interface Assignment {
  id: string;
  title: string;
  description: string;
  module: string;
  dueDate: string;
  totalPoints: number;
  instructions: string[];
  rubric: RubricItem[];
  status: 'active' | 'upcoming' | 'closed';
  createdAt: string;
  submissionsCount?: number;
}

export interface Submission {
  id: string;
  assignmentId: string;
  studentId: string;
  studentName: string;
  studentAvatar: string;
  submittedAt: string;
  content: string;
  fileUrl?: string;
  fileName?: string;
  status: 'submitted' | 'graded';
  score?: number;
  feedback?: string;
  aiGraded?: boolean;
  strengths?: string[];
  improvements?: string[];
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderRole: Role;
  text: string;
  timestamp: string;
  isQuestion?: boolean;
}

export interface LiveSlide {
  id: number;
  title: string;
  subtitle: string;
  bullets: string[];
  codeSnippet?: string;
}
