import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json({ limit: '10mb' }));

// Initialize Google GenAI client (server-side only)
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Helper to check AI availability
const getAI = () => {
  if (!ai && process.env.GEMINI_API_KEY) {
    ai = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return ai;
};

// API Route: Generate Course Material / Lecture Study Guide
app.post('/api/gemini/generate-material', async (req, res) => {
  try {
    const { topic, courseTitle, type = 'study-guide', targetAudience = 'Undergraduate' } = req.body;
    if (!topic) {
      return res.status(400).json({ error: 'Topic is required' });
    }

    const aiClient = getAI();
    if (!aiClient) {
      // Fallback content if API key is not yet set
      return res.json({
        title: `Comprehensive Guide: ${topic}`,
        summary: `Essential reference material covering key concepts, foundational principles, and practical workflows for ${topic} in ${courseTitle || 'the course'}.`,
        keyTakeaways: [
          `Fundamental understanding of core concepts in ${topic}`,
          'Key terminology and architectural mental models',
          'Industry best practices and implementation patterns',
          'Common pitfalls and debugging strategies',
        ],
        content: `### 1. Introduction to ${topic}\n\nUnderstanding ${topic} is critical for mastering modern applications in ${courseTitle || 'this discipline'}.\n\n### 2. Core Principles\n- **Principle A**: Clear modular boundaries and separation of concerns.\n- **Principle B**: Predictable data flow and robust verification.\n- **Principle C**: Performance optimization and resilience.\n\n### 3. Practical Code / Application\nWhen applying these concepts in live projects, ensure all components adhere to clean architecture and rigorous validation.\n\n### 4. Review Questions\n1. What is the primary advantage of this approach?\n2. How does this integrate with the wider curriculum?`,
        estimatedReadTime: '12 mins',
      });
    }

    const prompt = `You are a distinguished university professor designing high-impact course material.
Course: "${courseTitle || 'General Computer Science & Engineering'}"
Topic: "${topic}"
Material Type: "${type}"
Target Audience: "${targetAudience}"

Generate an exhaustive, well-structured, student-friendly learning material in JSON format.
The JSON must contain:
- title: string (engaging, academic title)
- summary: string (2-3 sentences overview)
- keyTakeaways: string[] (3-5 bullet points)
- content: string (rich Markdown formatted text with headers, bullet points, code or concept examples, and review questions)
- estimatedReadTime: string (e.g. "10 mins")`;

    const response = await aiClient.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            summary: { type: Type.STRING },
            keyTakeaways: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            content: { type: Type.STRING },
            estimatedReadTime: { type: Type.STRING },
          },
          required: ['title', 'summary', 'keyTakeaways', 'content', 'estimatedReadTime'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json(parsed);
  } catch (error: any) {
    console.error('Error generating material:', error);
    return res.status(500).json({ error: error.message || 'Failed to generate material' });
  }
});

// API Route: Generate Assignment
app.post('/api/gemini/generate-assignment', async (req, res) => {
  try {
    const { topic, courseTitle, difficulty = 'Medium', totalPoints = 100 } = req.body;
    if (!topic) {
      return res.status(400).json({ error: 'Topic is required' });
    }

    const aiClient = getAI();
    if (!aiClient) {
      return res.json({
        title: `Practical Assignment: ${topic}`,
        description: `Hands-on project and problem-solving set evaluating your conceptual mastery and practical implementation of ${topic}.`,
        module: courseTitle ? `${courseTitle} - Core Module` : 'Module 4',
        points: totalPoints,
        questions: [
          `Explain the foundational theoretical principles of ${topic} and contrast them with traditional approaches.`,
          `Implement a working prototype or demonstrate a step-by-step calculation solving a real-world scenario with ${topic}.`,
          `Critique two security or performance considerations related to ${topic} and provide mitigation strategies.`,
        ],
        rubric: [
          { criteria: 'Technical Accuracy & Completeness', points: 40 },
          { criteria: 'Problem Solving & Implementation', points: 35 },
          { criteria: 'Documentation & Code Quality', points: 25 },
        ],
        estimatedHours: '4-6 hours',
      });
    }

    const prompt = `You are an academic course director creating a modern university-level assignment.
Course: "${courseTitle || 'Software Engineering'}"
Topic: "${topic}"
Difficulty: "${difficulty}"
Total Points: ${totalPoints}

Generate a clear, rigorous, engaging assignment in JSON format with:
- title: string
- description: string (context and instructions)
- module: string
- questions: string[] (3-4 detailed questions or tasks)
- rubric: array of objects { criteria: string, points: number } that sum up to ${totalPoints}
- estimatedHours: string`;

    const response = await aiClient.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            description: { type: Type.STRING },
            module: { type: Type.STRING },
            questions: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            rubric: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  criteria: { type: Type.STRING },
                  points: { type: Type.NUMBER },
                },
                required: ['criteria', 'points'],
              },
            },
            estimatedHours: { type: Type.STRING },
          },
          required: ['title', 'description', 'module', 'questions', 'rubric', 'estimatedHours'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json(parsed);
  } catch (error: any) {
    console.error('Error generating assignment:', error);
    return res.status(500).json({ error: error.message || 'Failed to generate assignment' });
  }
});

// API Route: AI Grade & Feedback for Submissions
app.post('/api/gemini/grade-submission', async (req, res) => {
  try {
    const { assignmentTitle, assignmentDescription, studentSubmission, studentName, maxPoints = 100 } = req.body;
    if (!studentSubmission) {
      return res.status(400).json({ error: 'Student submission is required' });
    }

    const aiClient = getAI();
    if (!aiClient) {
      return res.json({
        score: Math.min(maxPoints, Math.floor(maxPoints * 0.92)),
        feedback: `Great work by ${studentName || 'the student'}! The submission demonstrates thorough understanding of ${assignmentTitle || 'the topic'} with clear explanations and organized solution structure.`,
        strengths: [
          'Clear conceptual grasp and structured explanation',
          'Good attention to edge cases and requirements',
          'Well-documented solution',
        ],
        improvements: [
          'Consider expanding on performance optimization nuances',
          'Could provide additional real-world bench testing metrics',
        ],
      });
    }

    const prompt = `You are a fair, encouraging, and meticulous university instructor grading a student assignment.
Assignment: "${assignmentTitle}"
Description: "${assignmentDescription}"
Student Name: "${studentName || 'Student'}"
Student Submission:
"""
${studentSubmission}
"""
Max Points: ${maxPoints}

Evaluate the submission fairly. Output JSON with:
- score: number (between 0 and ${maxPoints})
- feedback: string (comprehensive constructive paragraph addressed to the student)
- strengths: string[] (2-4 bullet points)
- improvements: string[] (1-3 actionable suggestions for growth)`;

    const response = await aiClient.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            score: { type: Type.NUMBER },
            feedback: { type: Type.STRING },
            strengths: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            improvements: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
          },
          required: ['score', 'feedback', 'strengths', 'improvements'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json(parsed);
  } catch (error: any) {
    console.error('Error grading submission:', error);
    return res.status(500).json({ error: error.message || 'Failed to grade submission' });
  }
});

// API Route: AI Study Assistant (Interactive Student Q&A)
app.post('/api/gemini/study-assistant', async (req, res) => {
  try {
    const { question, context, history = [] } = req.body;
    if (!question) {
      return res.status(400).json({ error: 'Question is required' });
    }

    const aiClient = getAI();
    if (!aiClient) {
      return res.json({
        answer: `That is a great question regarding ${context?.topic || 'the course material'}! In short, the key principle here is understanding how the components interact under standard conditions and how state propagates. When you break it down step-by-step, you will see how each module guarantees reliability and efficiency.`,
        relatedQuestions: [
          'How does this concept apply in production architectures?',
          'What are the common trade-offs compared to alternative approaches?',
        ],
      });
    }

    const prompt = `You are the AI Professor and Teaching Assistant for an elite university online classroom.
Course Context: ${JSON.stringify(context || {})}
Chat History: ${JSON.stringify(history.slice(-4))}
Student Question: "${question}"

Provide a direct, inspiring, clear educational response. Use Markdown format for readability (bolding, code blocks if relevant).
Also suggest 2 relevant follow-up questions the student might want to ask.
Output JSON with:
- answer: string (in markdown)
- relatedQuestions: string[] (2-3 short questions)`;

    const response = await aiClient.models.generateContent({
      model: 'gemini-3.1-flash-lite',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            answer: { type: Type.STRING },
            relatedQuestions: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
          },
          required: ['answer', 'relatedQuestions'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json(parsed);
  } catch (error: any) {
    console.error('Error in study assistant:', error);
    return res.status(500).json({ error: error.message || 'Failed to process question' });
  }
});

// API Route: AI Attendance Insights & Retention Analytics
app.post('/api/gemini/attendance-insights', async (req, res) => {
  try {
    const { attendanceStats, recentSessions } = req.body;
    const aiClient = getAI();

    if (!aiClient) {
      return res.json({
        healthScore: '94%',
        trend: 'Positive (+4% this week)',
        keyObservations: [
          'High participation in interactive Friday workshop sessions',
          'Morning check-in lag observed in 2 students (David Kim, Jordan Lee)',
          '91% average on-time check-in rate using the live PIN mechanism',
        ],
        recommendations: [
          'Send a gentle automated reminder 15 minutes before the session begins',
          'Reward consistent 100% attendance with bonus assignment tokens or digital badges',
          'Host a 5-minute interactive ice-breaker poll right at the start to drive punctuality',
        ],
      });
    }

    const prompt = `You are an educational data analyst assisting an instructor with class attendance trends.
Attendance Summary: ${JSON.stringify(attendanceStats || {})}
Recent Sessions: ${JSON.stringify(recentSessions || [])}

Analyze the data and provide actionable teaching insights in JSON format:
- healthScore: string (e.g. "92%")
- trend: string (e.g. "Upward (+3%)" or "Stable")
- keyObservations: string[] (3 bullet points)
- recommendations: string[] (3 practical steps for the instructor to increase student engagement and attendance)`;

    const response = await aiClient.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            healthScore: { type: Type.STRING },
            trend: { type: Type.STRING },
            keyObservations: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            recommendations: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
          },
          required: ['healthScore', 'trend', 'keyObservations', 'recommendations'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json(parsed);
  } catch (error: any) {
    console.error('Error generating attendance insights:', error);
    return res.status(500).json({ error: error.message || 'Failed to generate insights' });
  }
});

// Setup Vite middleware in dev or static files in production
async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, () => {
    console.log(`Classroom LMS Server running on http://localhost:${port}`);
  });
}

startServer();
